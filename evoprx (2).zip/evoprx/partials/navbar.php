<?php
// partials/navbar.php
if (session_status() === PHP_SESSION_NONE) { @session_start(); }

$BASE = $GLOBALS['BASE_URL'] ?? '';          // ej: https://realmedic.com.ec/evoprx
$BASE = rtrim($BASE, '/');

$u = function_exists('current_user') ? current_user() : null;
$role = $u['rol'] ?? '';
?>
<nav class="navbar navbar-expand-lg navbar-dark bg-dark no-print">
  <div class="container-fluid">
    <a class="navbar-brand" href="<?= e($BASE) ?>/index.php">Evo/Prx</a>

    <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navMain"
      aria-controls="navMain" aria-expanded="false" aria-label="Toggle navigation">
      <span class="navbar-toggler-icon"></span>
    </button>

    <div class="collapse navbar-collapse" id="navMain">
      <ul class="navbar-nav me-auto mb-2 mb-lg-0">

        <?php if ($u): ?>
          <li class="nav-item">
            <a class="nav-link" href="<?= e($BASE) ?>/patients/list.php">Pacientes</a>
          </li>

          <li class="nav-item">
            <a class="nav-link" href="<?= e($BASE) ?>/clinical/encounter.php">Encounter</a>
          </li>

          <li class="nav-item">
            <a class="nav-link" href="<?= e($BASE) ?>/assignments/patient_assign.php">Asignaciones</a>
          </li>

          <?php if ($role === 'admin'): ?>
            <li class="nav-item dropdown">
              <a class="nav-link dropdown-toggle" href="#" role="button" data-bs-toggle="dropdown" aria-expanded="false">
                Administraci�n
              </a>
              <ul class="dropdown-menu">
                <li><a class="dropdown-item" href="<?= e($BASE) ?>/users/list.php">Usuarios</a></li>
                <li><a class="dropdown-item" href="<?= e($BASE) ?>/users/signature.php">Sellos / Firmas</a></li>
                <li><hr class="dropdown-divider"></li>
                <li><a class="dropdown-item" href="<?= e($BASE) ?>/audits/list.php">Auditor�a</a></li>
              </ul>
            </li>
          <?php else: ?>
            <li class="nav-item">
              <a class="nav-link" href="<?= e($BASE) ?>/users/signature.php">Mi sello</a>
            </li>
          <?php endif; ?>

        <?php endif; ?>
      </ul>

      <ul class="navbar-nav ms-auto">
        <?php if ($u): ?>
          <li class="nav-item">
            <span class="navbar-text me-2">
              <?= e(($u['username'] ?? 'usuario')) ?> (<?= e($role ?: 'rol') ?>)
            </span>
          </li>
          <li class="nav-item">
            <a class="nav-link" href="<?= e($BASE) ?>/auth/logout.php">Salir</a>
          </li>
        <?php else: ?>
          <li class="nav-item">
            <a class="nav-link" href="<?= e($BASE) ?>/auth/login.php">Ingresar</a>
          </li>
        <?php endif; ?>
      </ul>
    </div>
  </div>
</nav>

<!-- Bootstrap JS (solo si tu layout NO lo carga ya) -->
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js"></script>
