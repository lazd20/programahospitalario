<?php
// partials/footer.php
require_once __DIR__ . '/../helpers.php';

$year = date('Y');

// Si quieres mostrar "Última actualización", define $last_update antes de incluir el footer.
// Ej: $last_update = '2026-01-16 08:45';
$last_update = $last_update ?? null;
?>
<footer class="border-top bg-light mt-5">
  <div class="container py-3">
    <div class="d-flex flex-column flex-md-row justify-content-between align-items-start align-items-md-center gap-2">
      <div class="text-muted small">
        © <?= e($year) ?> · Evo/Prx · Clínica / Historias Clínicas
      </div>

      <div class="text-muted small">
        <?php if ($last_update): ?>
          <span>Última actualización: <b><?= e($last_update) ?></b></span>
        <?php else: ?>
          <span class="d-none d-md-inline">Sistema de Evolución y Prescripciones</span>
        <?php endif; ?>
      </div>
    </div>
  </div>
</footer>
