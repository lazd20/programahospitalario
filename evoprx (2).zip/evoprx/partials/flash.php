<?php
// partials/flash.php
require_once __DIR__ . '/../helpers.php';

$messages = flash_get_all(); // ['success'=>'...', 'error'=>'...']
if (!$messages) return;

$map = [
  'success' => 'success',
  'error'   => 'danger',
  'warning' => 'warning',
  'info'    => 'info',
];
?>
<?php foreach ($messages as $type => $msg): ?>
  <?php $bs = $map[$type] ?? 'secondary'; ?>
  <div class="alert alert-<?= e($bs) ?> alert-dismissible fade show" role="alert">
    <?= e($msg) ?>
    <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Cerrar"></button>
  </div>
<?php endforeach; ?>
