<?php
// protocols/form.php
require_once __DIR__ . '/../auth.php';
require_login();
require_once __DIR__ . '/../helpers.php';

$BASE = $GLOBALS['BASE_URL'] ?? '';
$u = current_user();

$patient_id = (int)($_GET['patient_id'] ?? $_GET['id'] ?? 0);
if ($patient_id <= 0) {
  flash_set('error', 'Paciente inválido.');
  redirect($BASE . '/patients/list.php');
}

// ====== Cargar paciente ======
$stP = $pdo->prepare("SELECT * FROM patients WHERE id=? LIMIT 1");
$stP->execute([$patient_id]);
$patient = $stP->fetch();
if (!$patient) {
  flash_set('error', 'Paciente no encontrado.');
  redirect($BASE . '/patients/list.php');
}

// ====== Permisos ======
// - Residente: ve todo (si está asignado) pero NO edita
// - Especialista asignado: puede editar
// - Admin: puede editar
$rol = (string)($u['rol'] ?? '');
$can_view = false;
$can_edit = false;

if ($rol === 'admin') {
  $can_view = true;
  $can_edit = true;
} elseif ($rol === 'especialista') {
  $chk = $pdo->prepare("SELECT 1 FROM patient_doctors WHERE patient_id=? AND doctor_user_id=? LIMIT 1");
  $chk->execute([$patient_id, (int)$u['id']]);
  if ($chk->fetchColumn()) {
    $can_view = true;
    $can_edit = true;
  }
} else {
  // residente / viewer
  $chk = $pdo->prepare("SELECT 1 FROM resident_patients WHERE patient_id=? AND resident_user_id=? LIMIT 1");
  $chk->execute([$patient_id, (int)$u['id']]);
  if ($chk->fetchColumn()) {
    $can_view = true;
    $can_edit = false;
  }
}

if (!$can_view) {
  flash_set('error', 'No tienes acceso a este paciente.');
  redirect($BASE . '/patients/list.php');
}

// ====== Utilidades ======
function age_from_date($ymd) {
  if (!$ymd) return '';
  try {
    $dob = new DateTime($ymd);
    $now = new DateTime();
    return (string)$dob->diff($now)->y;
  } catch (Throwable $e) { return ''; }
}

$edad = age_from_date($patient['fecha_nac'] ?? null);

// ====== Establecimiento (solo 3 campos que te interesan) ======
$estab = [
  'institucion_sistema' => null,
  'unicodigo' => null,
  'establecimiento_salud' => null,
];

$establishment_id = (int)($patient['establishment_id'] ?? 0);
if ($establishment_id > 0) {
  $stE = $pdo->prepare("
    SELECT institucion_sistema, unicodigo, establecimiento_salud
    FROM establishments
    WHERE id=? LIMIT 1
  ");
  $stE->execute([$establishment_id]);
  $rowE = $stE->fetch();
  if ($rowE) $estab = array_merge($estab, $rowE);
} else {
  // fallback: primer establecimiento activo (si existe)
  $stE = $pdo->prepare("
    SELECT institucion_sistema, unicodigo, establecimiento_salud
    FROM establishments
    WHERE activo=1
    ORDER BY id ASC
    LIMIT 1
  ");
  $stE->execute();
  $rowE = $stE->fetch();
  if ($rowE) $estab = array_merge($estab, $rowE);
}

// ====== Cargar protocolo existente (1 por paciente: el más reciente) ======
$stProt = $pdo->prepare("
  SELECT *
  FROM surgical_protocols
  WHERE patient_id=?
  ORDER BY id DESC
  LIMIT 1
");
$stProt->execute([$patient_id]);
$prot = $stProt->fetch() ?: [];

$protocol_id = (int)($prot['id'] ?? 0);

// ====== Logo (si lo quieres en cabecera) ======
$logoUrl = 'https://realmedic.com.ec/pqx/uploads/logo.png';
?>
<!doctype html>
<html lang="es">
<head>
  <meta charset="utf-8" />
  <meta name="viewport" content="width=device-width, initial-scale=1" />
  <title>Protocolo Quirúrgico | <?= e(trim(($patient['apellidos'] ?? '').' '.($patient['nombres'] ?? ''))) ?></title>

  <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
  <!-- IMPORTANTE: aquí se carga tu CSS -->
  <link rel="stylesheet" href="<?= e($BASE) ?>/protocols/_ui.css?v=<?= time() ?>">

  <style>
    /* por si en hosting cachea fuerte */
    .protocol-head{
      padding: 10px 0 6px;
      border-bottom: 1px solid #111;
      display:flex;
      flex-direction:column;
      align-items:center;
      gap:6px;
    }
    .protocol-head img{ max-height:70px; max-width:260px; object-fit:contain; display:block; }
  </style>
</head>
<body>

<?php include __DIR__ . '/../partials/navbar.php'; ?>

<div class="container py-3 no-print">
  <?php include __DIR__ . '/../partials/flash.php'; ?>

  <div class="d-flex flex-wrap gap-2 align-items-center">
    <a class="btn btn-outline-secondary" href="<?= e($BASE) ?>/patients/view.php?id=<?= (int)$patient_id ?>">Volver</a>

    <?php if ($can_edit): ?>
      <button type="submit" form="protocolForm" class="btn btn-success">Guardar</button>
    <?php endif; ?>

    <a class="btn btn-dark" href="<?= e($BASE) ?>/protocols/print.php?patient_id=<?= (int)$patient_id ?>" target="_blank">Imprimir</a>

    <?php if (!$can_edit): ?>
      <span class="badge text-bg-secondary ms-auto">Solo lectura (residente)</span>
    <?php else: ?>
      <span class="badge text-bg-success ms-auto">Edición habilitada</span>
    <?php endif; ?>
  </div>
</div>

<div class="protocol-wrap">
  <div class="protocol-sheet">

    <div class="protocol-head">
      <img src="<?= e($logoUrl) ?>" alt="Logo">
      <h1 class="protocol-title">PROTOCOLO QUIRÚRGICO</h1>
      <p class="protocol-subtitle mb-0">Formulario MSP (digital)</p>
    </div>

    <form id="protocolForm" action="<?= e($BASE) ?>/protocols/actions/save.php" method="post" enctype="multipart/form-data">
      <input type="hidden" name="patient_id" value="<?= (int)$patient_id ?>">
      <input type="hidden" name="protocol_id" value="<?= (int)$protocol_id ?>">

      <?php if (!$can_edit): ?>
        <!-- si no edita, igual dejamos el form pero sin botón -->
        <input type="hidden" name="_readonly" value="1">
      <?php endif; ?>

      <fieldset <?= $can_edit ? '' : 'disabled' ?>>

        <?php
          // PASAMOS variables a secciones:
          // $patient, $estab, $edad, $prot, $u, $BASE
          include __DIR__ . '/sections/a_datos.php';
          include __DIR__ . '/sections/b_diagnosticos.php';
          include __DIR__ . '/sections/c_procedimiento.php';
          include __DIR__ . '/sections/d_equipo.php';
          include __DIR__ . '/sections/e_tipo_anestesia.php';
          include __DIR__ . '/sections/f_tiempos.php';
          include __DIR__ . '/sections/g_complicaciones.php';
          include __DIR__ . '/sections/h_histopatologicos.php';
          include __DIR__ . '/sections/i_diagrama.php';
          include __DIR__ . '/sections/j_responsables.php';
        ?>

      </fieldset>

      <div class="protocol-foot">
        <div>SNS-MSP/HCU-form. 017/2021</div>
        <div><b>PROTOCOLO QUIRÚRGICO</b></div>
      </div>
    </form>

  </div>
</div>

<!-- Bootstrap JS (modal) -->
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js"></script>

<!-- Helpers JS (CIE10 modal + binding) -->
<script>
(function(){
  // Une code|desc a un hidden dx (para que save.php use preop_dx1..)
  function setDxHidden(prefix, idx){
    const code = (document.querySelector(`[name="${prefix}_cie_code${idx}"]`) || {}).value || '';
    const desc = (document.querySelector(`[name="${prefix}_cie_desc${idx}"]`) || {}).value || '';
    const hidden = document.querySelector(`[name="${prefix}_dx${idx}"]`);
    if (!hidden) return;
    if (!code && !desc) hidden.value = '';
    else hidden.value = (code.trim() + '|' + desc.trim()).trim();
  }

  // listeners por si editan manualmente
  ['preop','postop'].forEach(function(prefix){
    [1,2,3].forEach(function(i){
      const c = document.querySelector(`[name="${prefix}_cie_code${i}"]`);
      const d = document.querySelector(`[name="${prefix}_cie_desc${i}"]`);
      if (c) c.addEventListener('input', () => setDxHidden(prefix, i));
      if (d) d.addEventListener('input', () => setDxHidden(prefix, i));
      setDxHidden(prefix, i);
    });
  });

  // Modal: agregar CIE10
  window.addCIE10 = function(){
    const target = document.querySelector('#cieTarget')?.value || 'preop';
    const code = (document.querySelector('#cieCode')?.value || '').trim();
    const desc = (document.querySelector('#cieDesc')?.value || '').trim();
    if (!code || !desc) {
      alert('Ingrese CIE-10 (código) y descripción.');
      return;
    }

    // buscar primera fila vacía (1..3)
    let placed = false;
    for (let i=1;i<=3;i++){
      const c = document.querySelector(`[name="${target}_cie_code${i}"]`);
      const d = document.querySelector(`[name="${target}_cie_desc${i}"]`);
      if (c && d && (!c.value && !d.value)){
        c.value = code;
        d.value = desc;
        // set hidden
        const h = document.querySelector(`[name="${target}_dx${i}"]`);
        if (h) h.value = code + '|' + desc;
        placed = true;
        break;
      }
    }

    if (!placed) {
      alert('Ya tienes 3 diagnósticos cargados en esta sección. (Si quieres más, migramos a tabla detalle).');
      return;
    }

    // limpiar modal
    document.querySelector('#cieCode').value = '';
    document.querySelector('#cieDesc').value = '';

    // cerrar modal
    const el = document.getElementById('cieModal');
    const modal = bootstrap.Modal.getInstance(el);
    if (modal) modal.hide();
  };
})();
</script>

</body>
</html>
