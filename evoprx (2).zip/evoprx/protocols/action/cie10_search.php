<?php
// protocols/actions/cie10_search.php
header('Content-Type: application/json; charset=UTF-8');
header('Cache-Control: no-store, no-cache, must-revalidate, max-age=0');

if (!function_exists('json_out')) {
  function json_out($arr, $code = 200) {
    http_response_code($code);
    echo json_encode($arr, JSON_UNESCAPED_UNICODE);
    exit;
  }
}

// ---- Cargar conexión PDO ----
// Ajusta SOLO si tu ruta real es distinta
try {
  if (!isset($pdo)) {
    $try1 = dirname(__DIR__, 2) . '/config.php'; // /evoprx/config.php (común)
    $try2 = dirname(__DIR__, 3) . '/config.php';
    if (file_exists($try1)) require_once $try1;
    elseif (file_exists($try2)) require_once $try2;
  }
} catch (Throwable $e) {
  json_out(['ok'=>false,'error'=>'No se pudo cargar config.php'], 500);
}

if (!isset($pdo)) {
  json_out(['ok'=>false,'error'=>'No hay conexión PDO disponible ($pdo)'], 500);
}

// ---- Input ----
$q = isset($_GET['q']) ? trim((string)$_GET['q']) : '';
if (mb_strlen($q) < 2) {
  json_out(['ok'=>true,'items'=>[]]);
}

$limit = 20;

// ---- Query ----
// Asumo tabla: cie10 (code, description)
// Si tu tabla se llama distinto, cambia $table y campos abajo.
$table = 'cie10';

try {
  // Si escribió algo tipo S83 o S83.5, buscamos por prefijo de código + LIKE en descripción
  $like = '%' . $q . '%';
  $prefix = $q . '%';

  $sql = "
    SELECT
      code AS code,
      description AS description
    FROM {$table}
    WHERE code LIKE :prefix
       OR description LIKE :like
    ORDER BY
      CASE WHEN code LIKE :prefix2 THEN 0 ELSE 1 END,
      code ASC
    LIMIT {$limit}
  ";

  $st = $pdo->prepare($sql);
  $st->execute([
    ':prefix'  => $prefix,
    ':prefix2' => $prefix,
    ':like'    => $like,
  ]);

  $items = $st->fetchAll(PDO::FETCH_ASSOC);
  if (!$items) $items = [];

  // Normaliza keys por si tu driver devuelve mayúsculas
  $out = array_map(function($r){
    return [
      'code' => (string)($r['code'] ?? $r['CODE'] ?? ''),
      'description' => (string)($r['description'] ?? $r['DESCRIPTION'] ?? ''),
    ];
  }, $items);

  json_out(['ok'=>true,'items'=>$out]);
} catch (Throwable $e) {
  // IMPORTANTE: si tu hosting no soporta LIMIT en SQL (Oracle, etc.)
  // esto fallará. Pero en MySQL va perfecto.
  json_out(['ok'=>false,'error'=>'SQL error','detail'=>$e->getMessage()], 500);
}
