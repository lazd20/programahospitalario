<?php
// protocols/actions/save.php
require_once __DIR__ . '/../../auth.php';
require_login();
require_once __DIR__ . '/../../helpers.php';

$BASE = $GLOBALS['BASE_URL'] ?? '';
$u    = current_user();

if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
  http_response_code(405);
  exit('Método no permitido');
}

$patient_id = (int)($_POST['patient_id'] ?? 0);
if ($patient_id <= 0) {
  flash_set('error', 'Paciente inválido.');
  redirect($BASE . '/patients/list.php');
}

/**
 * Permisos:
 * - admin: puede guardar
 * - especialista: solo si está asignado al paciente (patient_doctors)
 * - residente/viewer: solo ver (NO guardar)
 */
$rol = $u['rol'] ?? '';
if ($rol === 'residente' || $rol === 'viewer') {
  flash_set('error', 'No tienes permisos para llenar/guardar el protocolo. Solo el médico asignado.');
  redirect($BASE . '/protocols/form.php?patient_id=' . $patient_id);
}

if ($rol === 'especialista') {
  $chk = $pdo->prepare("SELECT 1 FROM patient_doctors WHERE patient_id=? AND doctor_user_id=? LIMIT 1");
  $chk->execute([$patient_id, (int)$u['id']]);
  if (!$chk->fetchColumn()) {
    flash_set('error', 'No tienes permisos: no estás asignado a este paciente.');
    redirect($BASE . '/patients/view.php?id=' . $patient_id);
  }
}

/** Helpers */
function post_str($k, $max = 255) {
  $v = trim((string)($_POST[$k] ?? ''));
  if ($v === '') return null;
  if ($max > 0) $v = mb_substr($v, 0, $max);
  return $v;
}
function post_int($k) {
  $v = $_POST[$k] ?? null;
  if ($v === null || $v === '') return null;
  return (int)$v;
}
function post_bool($k) {
  return isset($_POST[$k]) ? 1 : 0;
}
function post_date($k) {
  $v = trim((string)($_POST[$k] ?? ''));
  return $v !== '' ? $v : null; // YYYY-MM-DD
}
function post_time($k) {
  $v = trim((string)($_POST[$k] ?? ''));
  return $v !== '' ? $v : null; // HH:MM o HH:MM:SS
}

/**
 * Diagnósticos con CIE:
 * En el form puedes mandar arrays:
 *   preop_dx_code[]  preop_dx_desc[]
 *   postop_dx_code[] postop_dx_desc[]
 * Aquí lo guardamos compacto en preop_dx1..3, postop_dx1..3 como "CIE - Descripción".
 */
function build_dx($codeArrKey, $descArrKey, $limit = 3) {
  $codes = $_POST[$codeArrKey] ?? [];
  $descs = $_POST[$descArrKey] ?? [];
  $out = [];
  for ($i=0; $i < $limit; $i++) {
    $c = isset($codes[$i]) ? trim((string)$codes[$i]) : '';
    $d = isset($descs[$i]) ? trim((string)$descs[$i]) : '';
    if ($c === '' && $d === '') { $out[] = null; continue; }
    $val = trim($c . ($d !== '' ? ' - ' . $d : ''));
    $out[] = $val !== '' ? mb_substr($val, 0, 255) : null;
  }
  return $out; // [dx1, dx2, dx3]
}

list($preop1, $preop2, $preop3) = build_dx('preop_dx_code', 'preop_dx_desc', 3);
list($post1, $post2, $post3)   = build_dx('postop_dx_code', 'postop_dx_desc', 3);

/** Procedimiento (C) */
$proyectado        = post_str('proyectado', 255);
$realizado         = post_str('realizado', 255);
$procedimiento_tipo = post_str('procedimiento_tipo', 20); // electiva/emergencia/urgencia

/** Equipo (D) */
$cirujano_1         = post_str('cirujano_1', 255);
$cirujano_2         = post_str('cirujano_2', 255);
$instrumentista     = post_str('instrumentista', 255);
$circulante         = post_str('circulante', 255);

$primer_ayudante    = post_str('primer_ayudante', 255);
$segundo_ayudante   = post_str('segundo_ayudante', 255);
$tercer_ayudante    = post_str('tercer_ayudante', 255);

$anestesiologo      = post_str('anestesiologo', 255);
$ayudante_anestesia = post_str('ayudante_anestesia', 255);
$otros_integrantes  = post_str('otros_integrantes', 255);

/** Tipo anestesia (E) */
$tipo_anestesia      = post_str('tipo_anestesia', 20); // general/regional/sedacion/otros
$tipo_anestesia_otro = post_str('tipo_anestesia_otro', 255);

/** Tiempos + textos largos (F) */
$fecha_operacion   = post_date('fecha_operacion');
$hora_inicio       = post_time('hora_inicio');
$hora_terminacion  = post_time('hora_terminacion');

$hallazgos_quirurgicos   = trim((string)($_POST['hallazgos_quirurgicos'] ?? ''));
$dieresis                = trim((string)($_POST['dieresis'] ?? ''));
$exposicion_exploracion  = trim((string)($_POST['exposicion_exploracion'] ?? ''));
$procedimiento_quirurgico = trim((string)($_POST['procedimiento_quirurgico'] ?? ''));

/** Complicaciones (G) */
$complications_text = trim((string)($_POST['complications_text'] ?? ''));
$perdida_sanguinea_total_ml = post_int('perdida_sanguinea_total_ml');
$sangrado_aproximado_ml     = post_int('sangrado_aproximado_ml');
$uso_material_protesico     = post_bool('uso_material_protesico');

$complicaciones_ninguno = post_bool('complicaciones_ninguno');
if ($complications_text !== '') {
  // Si escribió complicaciones, asumimos que NO es "ninguno"
  $complicaciones_ninguno = 0;
}

$descripcion_insumos = trim((string)($_POST['descripcion_insumos'] ?? ''));
$transquirurgico     = trim((string)($_POST['transquirurgico'] ?? ''));

/** Histopatológicos (H) */
$biopsia_congelacion = isset($_POST['biopsia_congelacion']) ? (int)$_POST['biopsia_congelacion'] : null; // 1/0 o null
$biopsia_resultado   = post_str('biopsia_resultado', 255);
$patologo_reporta    = post_str('patologo_reporta', 255);
$histopatologico     = isset($_POST['histopatologico']) ? (int)$_POST['histopatologico'] : null; // 1/0 o null
$muestra             = post_str('muestra', 255);

/** Diagrama (I) - upload imagen */
$diagrama_path = post_str('diagrama_path', 255); // por si ya existía
if (!empty($_FILES['diagrama_file']['name'])) {
  $f = $_FILES['diagrama_file'];

  if ($f['error'] === UPLOAD_ERR_OK) {
    $tmp  = $f['tmp_name'];
    $mime = @mime_content_type($tmp) ?: '';
    $ok   = in_array($mime, ['image/png','image/jpeg','image/jpg','image/webp'], true);

    if (!$ok) {
      flash_set('error', 'El diagrama debe ser imagen (PNG/JPG/WEBP).');
      redirect($BASE . '/protocols/form.php?patient_id=' . $patient_id);
    }

    $ext = 'png';
    if ($mime === 'image/jpeg' || $mime === 'image/jpg') $ext = 'jpg';
    if ($mime === 'image/webp') $ext = 'webp';

    $relDir = 'uploads/protocols';
    $absDir = __DIR__ . '/../../' . $relDir;
    if (!is_dir($absDir)) @mkdir($absDir, 0755, true);

    $filename = 'diagram_p' . $patient_id . '_' . date('Ymd_His') . '_' . bin2hex(random_bytes(4)) . '.' . $ext;
    $absPath  = $absDir . '/' . $filename;

    if (!move_uploaded_file($tmp, $absPath)) {
      flash_set('error', 'No se pudo guardar la imagen del diagrama.');
      redirect($BASE . '/protocols/form.php?patient_id=' . $patient_id);
    }

    $diagrama_path = $relDir . '/' . $filename; // guardar relativo
  } else {
    flash_set('error', 'Error al subir la imagen del diagrama.');
    redirect($BASE . '/protocols/form.php?patient_id=' . $patient_id);
  }
}

/**
 * J. Responsable(s):
 * Por ahora tu tabla surgical_protocols no alcanza para 3 responsables.
 * En este save dejamos el hook para guardar si existe tabla:
 *   surgical_protocol_responsibles(protocol_id, user_id, especialidad, doc_identificacion, sort_order)
 *
 * Si todavía no existe, NO rompe el guardado del protocolo.
 */
$responsibles = $_POST['responsibles'] ?? []; 
// Esperado: responsibles[] = ['user_id'=>..,'especialidad'=>..,'doc_identificacion'=>..,'sort'=>..]

try {
  $pdo->beginTransaction();

  // 1) buscar si ya existe protocolo para este paciente (asumimos 1 por paciente)
  $stFind = $pdo->prepare("SELECT id, diagrama_path FROM surgical_protocols WHERE patient_id=? LIMIT 1");
  $stFind->execute([$patient_id]);
  $existing = $stFind->fetch(PDO::FETCH_ASSOC);

  if ($existing) {
    $protocol_id = (int)$existing['id'];

    // si no subieron nueva imagen, conserva la anterior
    if (!$diagrama_path) $diagrama_path = (string)($existing['diagrama_path'] ?? null);

    $sql = "
      UPDATE surgical_protocols SET
        updated_at = NOW(),
        preop_dx1=?, preop_dx2=?, preop_dx3=?,
        postop_dx1=?, postop_dx2=?, postop_dx3=?,
        proyectado=?, realizado=?, procedimiento_tipo=?,
        primer_ayudante=?, segundo_ayudante=?, tercer_ayudante=?,
        anestesiologo=?, ayudante_anestesia=?, otros_integrantes=?,
        cirujano_1=?, cirujano_2=?, instrumentista=?, circulante=?,
        tipo_anestesia=?, tipo_anestesia_otro=?,
        fecha_operacion=?, hora_inicio=?, hora_terminacion=?,
        hallazgos_quirurgicos=?, dieresis=?, exposicion_exploracion=?, procedimiento_quirurgico=?,
        uso_material_protesico=?, complicaciones_ninguno=?, complications_text=?,
        perdida_sanguinea_total_ml=?, sangrado_aproximado_ml=?,
        descripcion_insumos=?, transquirurgico=?,
        biopsia_congelacion=?, biopsia_resultado=?, patologo_reporta=?, histopatologico=?, muestra=?,
        diagrama_path=?
      WHERE id=? AND patient_id=?
    ";
    $stUp = $pdo->prepare($sql);
    $stUp->execute([
      $preop1, $preop2, $preop3,
      $post1, $post2, $post3,
      $proyectado, $realizado, $procedimiento_tipo,
      $primer_ayudante, $segundo_ayudante, $tercer_ayudante,
      $anestesiologo, $ayudante_anestesia, $otros_integrantes,
      $cirujano_1, $cirujano_2, $instrumentista, $circulante,
      $tipo_anestesia, $tipo_anestesia_otro,
      $fecha_operacion, $hora_inicio, $hora_terminacion,
      $hallazgos_quirurgicos, $dieresis, $exposicion_exploracion, $procedimiento_quirurgico,
      (int)$uso_material_protesico, (int)$complicaciones_ninguno, $complications_text,
      $perdida_sanguinea_total_ml, $sangrado_aproximado_ml,
      $descripcion_insumos, $transquirurgico,
      $biopsia_congelacion, $biopsia_resultado, $patologo_reporta, $histopatologico, $muestra,
      $diagrama_path,
      $protocol_id, $patient_id
    ]);

  } else {
    $sql = "
      INSERT INTO surgical_protocols (
        patient_id, author_user_id, created_at,
        preop_dx1, preop_dx2, preop_dx3,
        postop_dx1, postop_dx2, postop_dx3,
        proyectado, realizado, procedimiento_tipo,
        primer_ayudante, segundo_ayudante, tercer_ayudante,
        anestesiologo, ayudante_anestesia, otros_integrantes,
        cirujano_1, cirujano_2, instrumentista, circulante,
        tipo_anestesia, tipo_anestesia_otro,
        fecha_operacion, hora_inicio, hora_terminacion,
        hallazgos_quirurgicos, dieresis, exposicion_exploracion, procedimiento_quirurgico,
        uso_material_protesico, complicaciones_ninguno, complications_text,
        perdida_sanguinea_total_ml, sangrado_aproximado_ml,
        descripcion_insumos, transquirurgico,
        biopsia_congelacion, biopsia_resultado, patologo_reporta, histopatologico, muestra,
        diagrama_path
      ) VALUES (
        ?, ?, NOW(),
        ?, ?, ?,
        ?, ?, ?,
        ?, ?, ?,
        ?, ?, ?,
        ?, ?, ?,
        ?, ?, ?, ?,
        ?, ?,
        ?, ?, ?,
        ?, ?, ?, ?,
        ?, ?, ?,
        ?, ?,
        ?, ?,
        ?, ?, ?, ?, ?,
        ?
      )
    ";
    $stIn = $pdo->prepare($sql);
    $stIn->execute([
      $patient_id, (int)$u['id'],
      $preop1, $preop2, $preop3,
      $post1, $post2, $post3,
      $proyectado, $realizado, $procedimiento_tipo,
      $primer_ayudante, $segundo_ayudante, $tercer_ayudante,
      $anestesiologo, $ayudante_anestesia, $otros_integrantes,
      $cirujano_1, $cirujano_2, $instrumentista, $circulante,
      $tipo_anestesia, $tipo_anestesia_otro,
      $fecha_operacion, $hora_inicio, $hora_terminacion,
      $hallazgos_quirurgicos, $dieresis, $exposicion_exploracion, $procedimiento_quirurgico,
      (int)$uso_material_protesico, (int)$complicaciones_ninguno, $complications_text,
      $perdida_sanguinea_total_ml, $sangrado_aproximado_ml,
      $descripcion_insumos, $transquirurgico,
      $biopsia_congelacion, $biopsia_resultado, $patologo_reporta, $histopatologico, $muestra,
      $diagrama_path
    ]);

    $protocol_id = (int)$pdo->lastInsertId();
  }

  // 2) Guardar responsables si existe tabla (no rompe si no existe)
  if (is_array($responsibles) && count($responsibles) > 0) {
    try {
      // borra anteriores
      $pdo->prepare("DELETE FROM surgical_protocol_responsibles WHERE protocol_id=?")->execute([$protocol_id]);

      $ins = $pdo->prepare("
        INSERT INTO surgical_protocol_responsibles (protocol_id, user_id, especialidad, doc_identificacion, sort_order)
        VALUES (?, ?, ?, ?, ?)
      ");

      foreach ($responsibles as $idx => $rr) {
        $user_id = (int)($rr['user_id'] ?? 0);
        if ($user_id <= 0) continue;

        $esp  = trim((string)($rr['especialidad'] ?? ''));
        $doc  = trim((string)($rr['doc_identificacion'] ?? ''));
        $sort = isset($rr['sort_order']) ? (int)$rr['sort_order'] : ($idx + 1);

        $ins->execute([
          $protocol_id,
          $user_id,
          $esp !== '' ? mb_substr($esp, 0, 255) : null,
          $doc !== '' ? mb_substr($doc, 0, 50) : null,
          $sort
        ]);
      }
    } catch (Throwable $e) {
      // Si la tabla no existe o algo falla, NO tumbamos todo
      // (Luego lo normalizamos con su SQL cuando quieras)
    }
  }

  $pdo->commit();

  flash_set('success', 'Protocolo quirúrgico guardado correctamente.');
  redirect($BASE . '/protocols/form.php?patient_id=' . $patient_id);

} catch (Throwable $e) {
  if ($pdo->inTransaction()) $pdo->rollBack();
  flash_set('error', 'Error al guardar: ' . $e->getMessage());
  redirect($BASE . '/protocols/form.php?patient_id=' . $patient_id);
}
