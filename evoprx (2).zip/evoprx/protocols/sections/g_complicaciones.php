<?php
// protocols/sections/g_complicaciones.php
// Requiere: $sp (array) + helper e() + $can_edit (bool)

$sp = $sp ?? [];
$can_edit = isset($can_edit) ? (bool)$can_edit : true;

$compText   = (string)($sp['complicaciones_text'] ?? '');
$perdidaMl  = (string)($sp['perdida_sanguinea_total_ml'] ?? '');
$sangradoMl = (string)($sp['sangrado_aproximado_ml'] ?? '');
$desc       = (string)($sp['descripcion_insumos'] ?? '');

// IMPORTANTE: si no existe valor en DB, no preselecciona nada
$usoRaw = array_key_exists('uso_material_protesico', $sp) ? $sp['uso_material_protesico'] : null;
$usoProtes = ($usoRaw === null || $usoRaw === '') ? null : (int)$usoRaw;

$ro  = $can_edit ? '' : 'readonly';
$dis = $can_edit ? '' : 'disabled';
?>

<div class="sec-bar">G. COMPLICACIONES DEL PROCEDIMIENTO QUIRÚRGICO</div>

<table class="tbl">
  <colgroup>
    <col style="width:24%">
    <col style="width:18%">
    <col style="width:8%">
    <col style="width:24%">
    <col style="width:18%">
    <col style="width:8%">
  </colgroup>

  <tr>
    <td class="lbl" colspan="6">Complicaciones:</td>
  </tr>
  <tr>
    <td colspan="6">
      <textarea name="complicaciones_text" class="cell-textarea" rows="5" <?= $ro ?>><?= e($compText) ?></textarea>
    </td>
  </tr>

  <tr>
    <td class="lbl">Pérdida sanguínea total:</td>
    <td>
      <input type="number" min="0" step="1" name="perdida_sanguinea_total_ml" class="cell-input"
             value="<?= e($perdidaMl) ?>" <?= $ro ?>>
    </td>
    <td class="nowrap center">ml</td>

    <td class="lbl">Sangrado aproximado:</td>
    <td>
      <input type="number" min="0" step="1" name="sangrado_aproximado_ml" class="cell-input"
             value="<?= e($sangradoMl) ?>" <?= $ro ?>>
    </td>
    <td class="nowrap center">ml</td>
  </tr>

  <tr>
    <td class="lbl">Uso de material protésico:</td>
    <td colspan="5">
      <label class="chk" style="margin-right:14px;">
        <input <?= $dis ?> type="radio" name="uso_material_protesico" value="1" <?= ($usoProtes === 1) ? 'checked' : '' ?>>
        <span class="tag">SI</span>
      </label>

      <label class="chk">
        <input <?= $dis ?> type="radio" name="uso_material_protesico" value="0" <?= ($usoProtes === 0) ? 'checked' : '' ?>>
        <span class="tag">NO</span>
      </label>
    </td>
  </tr>

  <tr>
    <td class="lbl">Descripción:</td>
    <td colspan="5">
      <textarea name="descripcion_insumos" class="cell-textarea" rows="2" <?= $ro ?>><?= e($desc) ?></textarea>
    </td>
  </tr>
</table>
