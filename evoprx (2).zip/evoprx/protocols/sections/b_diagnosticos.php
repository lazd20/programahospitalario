<?php
// protocols/sections/b_diagnosticos.php
// Requiere: $can_edit (bool), helper e()
// Opcional: $dxRows = ['pre'=>[ ['code'=>'','desc'=>''], ...], 'post'=>[...] ]

$can_edit = isset($can_edit) ? (bool)$can_edit : false;
$dis = $can_edit ? '' : 'disabled';

$dxRows = $dxRows ?? ['pre'=>[], 'post'=>[]];

function _norm_dx($arr){
  $out = [];
  foreach (($arr ?: []) as $r) {
    $out[] = [
      'code' => (string)($r['code'] ?? $r['cie_code'] ?? ''),
      'desc' => (string)($r['desc'] ?? $r['cie_description'] ?? ''),
    ];
  }
  return $out;
}

$pre  = _norm_dx($dxRows['pre']  ?? []);
$post = _norm_dx($dxRows['post'] ?? []);

$minRows = 3;
while (count($pre)  < $minRows) $pre[]  = ['code'=>'','desc'=>''];
while (count($post) < $minRows) $post[] = ['code'=>'','desc'=>''];

// Endpoint (ajusta si tu base url cambia)
$CIE_ENDPOINT = rtrim(dirname($_SERVER['PHP_SELF']), '/') . '/action/cie10_search.php';

?>

<div class="sec-bar">B. DIAGNÓSTICOS</div>

<table class="tbl" id="dxTable">
  <colgroup>
    <col style="width:10%">
    <col style="width:4%">
    <col style="width:72%">
    <col style="width:14%">
  </colgroup>

  <thead>
    <tr>
      <th class="center"> </th>
      <th class="center"> </th>
      <th> </th>
      <th class="center">CIE</th>
    </tr>
  </thead>

  <tbody id="dxBody">
    <!-- PRE -->
    <?php foreach ($pre as $i => $d): ?>
      <tr class="dx-row" data-kind="pre">
        <?php if ($i === 0): ?>
          <td class="lbl center" rowspan="<?= (int)max($minRows, count($pre)) ?>">Pre<br>Operat.</td>
        <?php endif; ?>

        <td class="lbl center"><?= (int)($i+1) ?>.</td>

        <td>
          <input
            <?= $dis ?>
            type="text"
            class="cell-input dx-desc"
            name="preop_dx_desc[]"
            value="<?= e($d['desc']) ?>"
            placeholder=""
            autocomplete="off"
          >
        </td>

        <td>
          <input
            <?= $dis ?>
            type="text"
            class="cell-input center dx-code"
            name="preop_dx_code[]"
            value="<?= e($d['code']) ?>"
            placeholder=""
            autocomplete="off"
          >
        </td>
      </tr>
    <?php endforeach; ?>

    <!-- POST -->
    <?php foreach ($post as $i => $d): ?>
      <tr class="dx-row" data-kind="post">
        <?php if ($i === 0): ?>
          <td class="lbl center" rowspan="<?= (int)max($minRows, count($post)) ?>">Post<br>Operat.</td>
        <?php endif; ?>

        <td class="lbl center"><?= (int)($i+1) ?>.</td>

        <td>
          <input
            <?= $dis ?>
            type="text"
            class="cell-input dx-desc"
            name="postop_dx_desc[]"
            value="<?= e($d['desc']) ?>"
            placeholder=""
            autocomplete="off"
          >
        </td>

        <td>
          <input
            <?= $dis ?>
            type="text"
            class="cell-input center dx-code"
            name="postop_dx_code[]"
            value="<?= e($d['code']) ?>"
            placeholder=""
            autocomplete="off"
          >
        </td>
      </tr>
    <?php endforeach; ?>
  </tbody>
</table>

<?php if ($can_edit): ?>
  <div class="mt-6 no-print" style="display:flex; gap:8px; flex-wrap:wrap;">
    <button type="button" class="btn-mini" onclick="DxMSP.addRow('pre')">+ Pre operatorio</button>
    <button type="button" class="btn-mini" onclick="DxMSP.addRow('post')">+ Post operatorio</button>
  </div>
<?php endif; ?>

<!-- Dropdown de sugerencias -->
<div id="dxSuggest" style="position:absolute; z-index:9999; display:none; background:#fff; border:1px solid var(--grid); min-width:260px; max-width:520px; box-shadow:0 6px 18px rgba(0,0,0,.08);">
  <div id="dxSuggestBody" style="max-height:220px; overflow:auto;"></div>
</div>

<script>
(function(){
  if (window.__DxMSPInit) return;
  window.__DxMSPInit = true;

  const CAN_EDIT = <?= $can_edit ? 'true' : 'false' ?>;
  if (!CAN_EDIT) return;

  const ENDPOINT = <?= json_encode($CIE_ENDPOINT) ?>;
  const body = document.getElementById('dxBody');
  const suggest = document.getElementById('dxSuggest');
  const suggestBody = document.getElementById('dxSuggestBody');

  let activeInput = null;
  let timer = null;

  function esc(s){
    return String(s).replaceAll('&','&amp;').replaceAll('<','&lt;').replaceAll('>','&gt;').replaceAll('"','&quot;').replaceAll("'","&#039;");
  }

  function positionSuggest(input){
    const r = input.getBoundingClientRect();
    suggest.style.left = (window.scrollX + r.left) + 'px';
    suggest.style.top  = (window.scrollY + r.bottom + 2) + 'px';
    suggest.style.minWidth = Math.max(260, r.width) + 'px';
  }

  async function searchCIE(q){
    const url = ENDPOINT + '?q=' + encodeURIComponent(q);
    const res = await fetch(url, { headers: { 'Accept':'application/json' }});
    const data = await res.json();
    return (data && data.ok && Array.isArray(data.items)) ? data.items : [];
  }

  function showSuggest(input, items){
    if (!items.length) { hideSuggest(); return; }
    activeInput = input;
    positionSuggest(input);

    suggestBody.innerHTML = items.map(it => {
      const code = (it.code || '').trim();
      const desc = (it.description || '').trim();
      return `
        <div class="dx-item" data-code="${esc(code)}" data-desc="${esc(desc)}"
             style="padding:6px 8px; border-bottom:1px solid #eee; cursor:pointer;">
          <div style="font-weight:800;">${esc(code)} <span style="font-weight:400; color:#666;">${esc(desc)}</span></div>
        </div>
      `;
    }).join('');

    suggest.style.display = 'block';
  }

  function hideSuggest(){
    suggest.style.display = 'none';
    suggestBody.innerHTML = '';
    activeInput = null;
  }

  function applyToRow(input, code, desc){
    const tr = input.closest('tr');
    if (!tr) return;
    const codeInput = tr.querySelector('.dx-code');
    const descInput = tr.querySelector('.dx-desc');
    if (codeInput) codeInput.value = code || '';
    if (descInput) descInput.value = desc || '';
  }

  suggest.addEventListener('mousedown', function(ev){
    const item = ev.target.closest('.dx-item');
    if (!item || !activeInput) return;
    ev.preventDefault();
    applyToRow(activeInput, item.dataset.code || '', item.dataset.desc || '');
    hideSuggest();
  });

  document.addEventListener('click', function(ev){
    if (!suggest.contains(ev.target)) hideSuggest();
  });

  function onType(ev){
    const input = ev.target;
    if (!input.classList.contains('dx-code') && !input.classList.contains('dx-desc')) return;

    const q = (input.value || '').trim();
    if (q.length < 2) { hideSuggest(); return; }

    clearTimeout(timer);
    timer = setTimeout(async () => {
      try{
        const items = await searchCIE(q);
        showSuggest(input, items);
      }catch(e){
        hideSuggest();
      }
    }, 180);
  }

  body.addEventListener('input', onType);
  window.addEventListener('scroll', () => { if (activeInput) positionSuggest(activeInput); }, {passive:true});
  window.addEventListener('resize', () => { if (activeInput) positionSuggest(activeInput); }, {passive:true});

  // API para agregar filas (manteniendo el look MSP)
  window.DxMSP = {
    addRow(kind){
      // kind: 'pre' o 'post'
      const rows = Array.from(body.querySelectorAll('tr.dx-row[data-kind="'+kind+'"]'));
      const n = rows.length + 1;

      // Crear TR
      const tr = document.createElement('tr');
      tr.className = 'dx-row';
      tr.dataset.kind = kind;

      // ¿Tiene label rowspan? lo tiene solo la primera fila; al agregar, hay que aumentar el rowspan
      const firstRow = rows[0] || null;
      const labelCell = firstRow ? firstRow.querySelector('td.lbl[rowspan]') : null;
      if (labelCell) {
        labelCell.setAttribute('rowspan', String(n));
      }

      // Columna 1 (label) solo si NO hay filas previas
      let c1 = '';
      if (!rows.length) {
        const txt = (kind === 'pre') ? 'Pre<br>Operat.' : 'Post<br>Operat.';
        c1 = `<td class="lbl center" rowspan="1">${txt}</td>`;
      }

      const nameDesc = (kind === 'pre') ? 'preop_dx_desc[]' : 'postop_dx_desc[]';
      const nameCode = (kind === 'pre') ? 'preop_dx_code[]' : 'postop_dx_code[]';

      tr.innerHTML = `
        ${c1}
        <td class="lbl center">${n}.</td>
        <td><input type="text" class="cell-input dx-desc" name="${nameDesc}" value="" autocomplete="off"></td>
        <td><input type="text" class="cell-input center dx-code" name="${nameCode}" value="" autocomplete="off"></td>
      `;

      // Insertar al final del bloque (pre o post)
      if (kind === 'pre') {
        // antes del primer post
        const firstPost = body.querySelector('tr.dx-row[data-kind="post"]');
        if (firstPost) body.insertBefore(tr, firstPost);
        else body.appendChild(tr);
      } else {
        body.appendChild(tr);
      }

      // Re-numerar (por si se inserta en medio)
      renumber(kind);
    }
  };

  function renumber(kind){
    const rows = Array.from(body.querySelectorAll('tr.dx-row[data-kind="'+kind+'"]'));
    rows.forEach((tr, idx) => {
      const numCell = tr.querySelector('td.lbl.center:not([rowspan])');
      if (numCell) numCell.textContent = (idx+1)+'.';
    });
  }
})();
</script>
