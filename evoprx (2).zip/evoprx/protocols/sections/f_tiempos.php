<?php
// protocols/sections/f_tiempos.php
// Requiere (desde protocols/form.php):
// - $proto (array del protocolo actual; puede estar vacío en create)
// - $readonly (bool) si el usuario solo puede ver
//
// Campos en surgical_protocols usados aquí:
// fecha_operacion (date)
// hora_inicio (time)
// hora_terminacion (time)
// hallazgos_quirurgicos (mediumtext)
// dieresis (mediumtext)
// exposicion_exploracion (mediumtext)
// procedimiento_quirurgico (mediumtext)

$fecha      = (string)($proto['fecha_operacion'] ?? '');
$horaInicio = (string)($proto['hora_inicio'] ?? '');
$horaFin    = (string)($proto['hora_terminacion'] ?? '');

$dia = $mes = $anio = '';
if ($fecha) {
  $parts = explode('-', $fecha); // yyyy-mm-dd
  if (count($parts) === 3) {
    $anio = $parts[0];
    $mes  = $parts[1];
    $dia  = $parts[2];
  }
}

$dis = $readonly ? 'disabled' : '';
?>

<!-- F. TIEMPOS QUIRÚRGICOS -->
<div class="sec-bar">F. TIEMPOS QUIRÚRGICOS</div>

<table class="tbl">
  <colgroup>
    <col style="width:26%">
    <col style="width:10%">
    <col style="width:10%">
    <col style="width:14%">
    <col style="width:20%">
    <col style="width:20%">
  </colgroup>
  <thead>
    <tr>
      <th>FECHA DE OPERACIÓN</th>
      <th class="center">DÍA</th>
      <th class="center">MES</th>
      <th class="center">AÑO</th>
      <th class="center">HORA DE INICIO</th>
      <th class="center">HORA DE TERMINACIÓN</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <td class="lbl">Anestesia</td>

      <td class="center">
        <input
          type="number" min="1" max="31"
          class="box-input xs"
          name="fecha_dia"
          value="<?= htmlspecialchars((string)$dia) ?>"
          <?= $dis ?>
          data-date="dia"
        >
      </td>

      <td class="center">
        <input
          type="number" min="1" max="12"
          class="box-input xs"
          name="fecha_mes"
          value="<?= htmlspecialchars(ltrim((string)$mes,'0')) ?>"
          <?= $dis ?>
          data-date="mes"
        >
      </td>

      <td class="center">
        <input
          type="number" min="1900" max="2100"
          class="box-input sm"
          name="fecha_anio"
          value="<?= htmlspecialchars((string)$anio) ?>"
          <?= $dis ?>
          data-date="anio"
        >
      </td>

      <td class="center">
        <input
          type="time"
          class="box-input sm"
          name="hora_inicio"
          value="<?= htmlspecialchars($horaInicio) ?>"
          <?= $dis ?>
        >
      </td>

      <td class="center">
        <input
          type="time"
          class="box-input sm"
          name="hora_terminacion"
          value="<?= htmlspecialchars($horaFin) ?>"
          <?= $dis ?>
        >
      </td>
    </tr>
  </tbody>
</table>

<!-- Guardamos la fecha real aquí (YYYY-MM-DD) -->
<input
  type="hidden"
  name="fecha_operacion"
  id="fecha_operacion_hidden"
  value="<?= htmlspecialchars($fecha) ?>"
>

<table class="tbl">
  <colgroup>
    <col style="width:28%">
    <col style="width:72%">
  </colgroup>
  <tbody>
    <tr>
      <td class="lbl">Hallazgos Quirúrgicos</td>
      <td>
        <textarea class="cell-textarea" name="hallazgos_quirurgicos" rows="7" <?= $dis ?>><?= htmlspecialchars((string)($proto['hallazgos_quirurgicos'] ?? '')) ?></textarea>
      </td>
    </tr>

    <tr>
      <td class="lbl">Dieresis</td>
      <td>
        <textarea class="cell-textarea" name="dieresis" rows="6" <?= $dis ?>><?= htmlspecialchars((string)($proto['dieresis'] ?? '')) ?></textarea>
      </td>
    </tr>

    <tr>
      <td class="lbl">Exposición / Exploración</td>
      <td>
        <textarea class="cell-textarea" name="exposicion_exploracion" rows="10" <?= $dis ?>><?= htmlspecialchars((string)($proto['exposicion_exploracion'] ?? '')) ?></textarea>
      </td>
    </tr>

    <tr>
      <td class="lbl">Procedimiento Quirúrgico</td>
      <td>
        <textarea class="cell-textarea" name="procedimiento_quirurgico" rows="10" <?= $dis ?>><?= htmlspecialchars((string)($proto['procedimiento_quirurgico'] ?? '')) ?></textarea>
      </td>
    </tr>
  </tbody>
</table>

<script>
(function(){
  const hidden = document.getElementById('fecha_operacion_hidden');
  const dEl = document.querySelector('[data-date="dia"]');
  const mEl = document.querySelector('[data-date="mes"]');
  const yEl = document.querySelector('[data-date="anio"]');
  if (!hidden || !dEl || !mEl || !yEl) return;

  function pad2(v){
    v = String(v || '').trim();
    return v.length === 1 ? ('0' + v) : v;
  }

  function build(){
    const d = pad2(dEl.value);
    const m = pad2(mEl.value);
    const y = String(yEl.value || '').trim();
    if (y && m && d) hidden.value = `${y}-${m}-${d}`;
  }

  ['input','change'].forEach(ev => {
    dEl.addEventListener(ev, build);
    mEl.addEventListener(ev, build);
    yEl.addEventListener(ev, build);
  });

  build();
})();
</script>
