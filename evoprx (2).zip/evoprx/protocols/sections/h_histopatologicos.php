<?php
// protocols/sections/h_histopatologicos.php
// Requiere: $sp (array) y $can_edit (bool) y helper e()

$trans = (string)($sp['transquirurgico'] ?? '');

$biopsiaCong = array_key_exists('biopsia_congelacion', $sp) ? (string)$sp['biopsia_congelacion'] : ''; // '1'/'0'/''
$biopsiaRes  = (string)($sp['biopsia_resultado'] ?? '');

$patologo    = (string)($sp['patologo_reporta'] ?? '');

$histo       = array_key_exists('histopatologico', $sp) ? (string)$sp['histopatologico'] : ''; // '1'/'0'/''
$muestra     = (string)($sp['muestra'] ?? '');

$disabled = empty($can_edit) ? 'disabled' : '';

function checked_radio_str($val, $current) {
  return ((string)$val === (string)$current) ? 'checked' : '';
}
?>

<div class="sec-bar">H. EXÁMENES HISTOPATOLÓGICOS</div>

<table class="tbl">
  <colgroup>
    <col style="width:22%">
    <col style="width:28%">
    <col style="width:12%">
    <col style="width:38%">
  </colgroup>

  <!-- Transquirúrgico -->
  <tr>
    <td class="lbl">Transquirúrgico:</td>
    <td colspan="3">
      <input type="text" name="transquirurgico" class="cell-input" value="<?= e($trans) ?>" <?= $disabled ? 'readonly' : '' ?>>
    </td>
  </tr>

  <!-- Biopsia por congelación + Resultado -->
  <tr>
    <td class="lbl">Biopsia por congelación:</td>
    <td>
      <div class="opt-row">
        <label class="chk">
          <input <?= $disabled ?> type="radio" name="biopsia_congelacion" value="1" <?= checked_radio_str('1', $biopsiaCong) ?>>
          <span class="tag">SI</span>
        </label>

        <label class="chk">
          <input <?= $disabled ?> type="radio" name="biopsia_congelacion" value="0" <?= checked_radio_str('0', $biopsiaCong) ?>>
          <span class="tag">NO</span>
        </label>
      </div>
    </td>

    <td class="lbl">Resultado:</td>
    <td>
      <input type="text" name="biopsia_resultado" class="cell-input" value="<?= e($biopsiaRes) ?>" <?= $disabled ? 'readonly' : '' ?>>
    </td>
  </tr>

  <!-- Patólogo -->
  <tr>
    <td class="lbl">Patólogo que reporta:</td>
    <td colspan="3">
      <input type="text" name="patologo_reporta" class="cell-input" value="<?= e($patologo) ?>" <?= $disabled ? 'readonly' : '' ?>>
    </td>
  </tr>

  <!-- Histopatológico + Muestra -->
  <tr>
    <td class="lbl">Histopatológico:</td>
    <td>
      <div class="opt-row">
        <label class="chk">
          <input <?= $disabled ?> type="radio" name="histopatologico" value="1" <?= checked_radio_str('1', $histo) ?>>
          <span class="tag">SI</span>
        </label>

        <label class="chk">
          <input <?= $disabled ?> type="radio" name="histopatologico" value="0" <?= checked_radio_str('0', $histo) ?>>
          <span class="tag">NO</span>
        </label>
      </div>
    </td>

    <td class="lbl">Muestra:</td>
    <td>
      <input type="text" name="muestra" class="cell-input" value="<?= e($muestra) ?>" <?= $disabled ? 'readonly' : '' ?>>
    </td>
  </tr>
</table>
