<?php
/**
 * protocols/sections/j_responsables.php
 * - 3 responsables (no 4)
 * - Permite manual o seleccionar doctor
 * - Al seleccionar doctor: carga rubrica + sello del MISMO doctor
 */

if (!function_exists('e')) {
  function e($v){ return htmlspecialchars((string)$v, ENT_QUOTES, 'UTF-8'); }
}

/** Intentar asegurar $pdo sin romper tu proyecto (no forzamos include si ya existe) */
if (!isset($pdo)) {
  // Ajusta estas rutas si tu config.php está en otro lado
  $try1 = dirname(__DIR__, 2) . '/config.php';        // /protocols/config.php (si existiera)
  $try2 = dirname(__DIR__, 3) . '/config.php';        // /evoprx/config.php (común)
  if (file_exists($try1)) require_once $try1;
  elseif (file_exists($try2)) require_once $try2;
}

$BASE = isset($BASE) ? rtrim((string)$BASE, '/') : ''; // opcional

function asset_url_local($base, $path){
  $path = trim((string)$path);
  if ($path === '') return '';
  // Si ya viene con http(s), lo dejamos
  if (preg_match('~^https?://~i', $path)) return $path;
  $path = ltrim($path, '/');
  return $base ? ($base . '/' . $path) : ('/' . $path);
}

$MAX_RESP = 3;

// Cargar doctores desde DB aquí mismo (para que no dependas de form.php)
$usersList = [];
try {
  if (isset($pdo)) {
    // Ajusta roles si deseas incluir otros
    $st = $pdo->prepare("SELECT id, nombre, apellido, rol, rubrica_path, sello_path
                         FROM users
                         WHERE rol IN ('admin','especialista')
                         ORDER BY apellido ASC, nombre ASC");
    $st->execute();
    $usersList = $st->fetchAll(PDO::FETCH_ASSOC) ?: [];
  }
} catch (Exception $e) {
  $usersList = [];
}

// Responsables guardados (si form.php los pasa)
$responsables = $responsables ?? [];

?>
<div class="sec-bar">J. DATOS DEL PROFESIONAL RESPONSABLE</div>

<table class="tbl">
  <colgroup>
    <col style="width:30%">
    <col style="width:20%">
    <col style="width:22%">
    <col style="width:28%">
  </colgroup>
  <thead>
    <tr>
      <th>NOMBRE Y APELLIDOS</th>
      <th>ESPECIALIDAD</th>
      <th>FIRMA</th>
      <th>SELLO Y NÚMERO DE DOCUMENTO<br>DE IDENTIFICACIÓN</th>
    </tr>
  </thead>

  <tbody>
    <?php for ($i=0; $i<$MAX_RESP; $i++):
      $r = $responsables[$i] ?? [];

      $userId = (int)($r['user_id'] ?? 0);
      $nombreCompleto = trim((string)($r['nombre_apellidos'] ?? ''));
      $especialidad = (string)($r['especialidad'] ?? '');
      $doc = (string)($r['doc_identificacion'] ?? '');

      $rubrica = (string)($r['rubrica_path'] ?? '');
      $sello   = (string)($r['sello_path'] ?? '');

      $rubricaUrl = asset_url_local($BASE, $rubrica);
      $selloUrl   = asset_url_local($BASE, $sello);
    ?>
    <tr class="resp-row" data-idx="<?= (int)$i ?>">
      <!-- Nombre y apellidos -->
      <td>
        <div style="display:flex; flex-direction:column; gap:6px;">
          <select class="cell-select resp-user" name="responsables[<?= (int)$i ?>][user_id]">
            <option value="0">— (Manual) —</option>
            <?php foreach ($usersList as $u):
              $uid = (int)($u['id'] ?? 0);
              $uname = trim((string)($u['nombre'] ?? '') . ' ' . (string)($u['apellido'] ?? ''));
            ?>
              <option value="<?= $uid ?>" <?= $uid===$userId ? 'selected' : '' ?>>
                <?= e($uname) ?>
              </option>
            <?php endforeach; ?>
          </select>

          <input
            class="box-input resp-name"
            name="responsables[<?= (int)$i ?>][nombre_apellidos]"
            value="<?= e($nombreCompleto) ?>"
            placeholder="Nombre y apellidos (si es manual)"
          >
        </div>
      </td>

      <!-- Especialidad -->
      <td>
        <input
          class="box-input"
          name="responsables[<?= (int)$i ?>][especialidad]"
          value="<?= e($especialidad) ?>"
          placeholder="Especialidad"
        >
      </td>

      <!-- Firma -->
      <td class="center">
        <div class="sigbox">
          <div class="sig-imgwrap" style="width:100%; min-height:44px; border:1px solid var(--grid); background:#fff; display:flex; align-items:center; justify-content:center;">
            <img class="resp-rubrica-img" src="<?= e($rubricaUrl) ?>" alt="" style="<?= $rubricaUrl ? '' : 'display:none;' ?> max-height:40px;">
          </div>

          <input type="hidden" class="resp-rubrica" name="responsables[<?= (int)$i ?>][rubrica_path]" value="<?= e($rubrica) ?>">
        </div>
      </td>

      <!-- Sello + Documento -->
      <td>
        <div style="display:flex; gap:8px; align-items:flex-start;">
          <div style="flex:0 0 120px;">
            <div style="width:120px; min-height:44px; border:1px solid var(--grid); background:#fff; display:flex; align-items:center; justify-content:center;">
              <img class="resp-sello-img" src="<?= e($selloUrl) ?>" alt="" style="<?= $selloUrl ? '' : 'display:none;' ?> max-height:40px;">
            </div>
            <input type="hidden" class="resp-sello" name="responsables[<?= (int)$i ?>][sello_path]" value="<?= e($sello) ?>">
          </div>

          <div style="flex:1;">
            <input
              class="box-input"
              name="responsables[<?= (int)$i ?>][doc_identificacion]"
              value="<?= e($doc) ?>"
              placeholder="N° documento"
            >
          </div>
        </div>
      </td>
    </tr>
    <?php endfor; ?>
  </tbody>
</table>

<script>
(function(){
  // Guard para no duplicar el init si el archivo se incluye más de una vez
  if (window.__protRespInit) return;
  window.__protRespInit = true;

  const BASE = <?= json_encode($BASE) ?>;

  const usersMap = <?= json_encode(array_reduce($usersList, function($acc, $u){
    $id = (int)($u['id'] ?? 0);
    if (!$id) return $acc;
    $acc[$id] = [
      'nombre' => trim((string)($u['nombre'] ?? '')),
      'apellido' => trim((string)($u['apellido'] ?? '')),
      'rubrica_path' => (string)($u['rubrica_path'] ?? ''),
      'sello_path' => (string)($u['sello_path'] ?? ''),
    ];
    return $acc;
  }, []), JSON_UNESCAPED_UNICODE) ?>;

  function assetUrl(path){
    path = (path || '').trim();
    if (!path) return '';
    if (/^https?:\/\//i.test(path)) return path;
    path = path.replace(/^\/+/, '');
    return (BASE ? (BASE + '/' + path) : ('/' + path));
  }

  function syncRow(tr){
    const sel = tr.querySelector('.resp-user');
    const nameInput = tr.querySelector('.resp-name');

    const rubHidden = tr.querySelector('.resp-rubrica');
    const selloHidden = tr.querySelector('.resp-sello');
    const rubImg = tr.querySelector('.resp-rubrica-img');
    const selloImg = tr.querySelector('.resp-sello-img');

    const uid = parseInt(sel.value || '0', 10);

    if (!uid || !usersMap[uid]) {
      // Manual: no tocamos nombre si ya escribió; solo limpiamos imágenes si no hay valores ocultos
      const rubPath = (rubHidden.value || '').trim();
      const selloPath = (selloHidden.value || '').trim();

      if (rubPath) {
        rubImg.src = assetUrl(rubPath);
        rubImg.style.display = '';
      } else {
        rubImg.removeAttribute('src');
        rubImg.style.display = 'none';
      }

      if (selloPath) {
        selloImg.src = assetUrl(selloPath);
        selloImg.style.display = '';
      } else {
        selloImg.removeAttribute('src');
        selloImg.style.display = 'none';
      }
      return;
    }

    const u = usersMap[uid];
    const fullName = (u.nombre + ' ' + u.apellido).trim();

    // Autocompleta nombre (pero si quieres que el usuario pueda editarlo, lo dejamos editable igual)
    nameInput.value = fullName;

    // Firma / sello del médico seleccionado
    rubHidden.value = u.rubrica_path || '';
    selloHidden.value = u.sello_path || '';

    if (u.rubrica_path) {
      rubImg.src = assetUrl(u.rubrica_path);
      rubImg.style.display = '';
    } else {
      rubImg.removeAttribute('src');
      rubImg.style.display = 'none';
    }

    if (u.sello_path) {
      selloImg.src = assetUrl(u.sello_path);
      selloImg.style.display = '';
    } else {
      selloImg.removeAttribute('src');
      selloImg.style.display = 'none';
    }
  }

  document.querySelectorAll('tr.resp-row').forEach(tr => {
    const sel = tr.querySelector('.resp-user');
    sel.addEventListener('change', () => syncRow(tr));
    syncRow(tr); // init
  });
})();
</script>
