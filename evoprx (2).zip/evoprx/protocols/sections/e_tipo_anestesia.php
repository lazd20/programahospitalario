<?php
// protocols/sections/e_tipo_anestesia.php
// Requiere:
// - $sp (array del protocolo; puede venir vacío)
// - $can_edit (bool)

$tipo = (string)($sp['tipo_anestesia'] ?? '');
$otro = (string)($sp['tipo_anestesia_otro'] ?? '');

$disabled = empty($can_edit) ? 'disabled' : '';

function checked_radio($val, $current) {
  return ($val === $current) ? 'checked' : '';
}
?>

<div class="sec-bar">E. TIPO ANESTESIA</div>

<table class="tbl">
  <colgroup>
    <col style="width:35%">
    <col style="width:65%">
  </colgroup>

  <tbody>
    <tr>
      <td class="lbl">Tipo de anestesia:</td>
      <td>
        <div class="opt-row">
          <label class="chk">
            <input <?= $disabled ?> type="radio" name="tipo_anestesia" value="general" <?= checked_radio('general', $tipo) ?>>
            <span class="tag">General</span>
          </label>

          <label class="chk">
            <input <?= $disabled ?> type="radio" name="tipo_anestesia" value="regional" <?= checked_radio('regional', $tipo) ?>>
            <span class="tag">Regional</span>
          </label>

          <label class="chk">
            <input <?= $disabled ?> type="radio" name="tipo_anestesia" value="sedacion" <?= checked_radio('sedacion', $tipo) ?>>
            <span class="tag">Sedación</span>
          </label>

          <label class="chk">
            <input <?= $disabled ?> type="radio" name="tipo_anestesia" value="otros" <?= checked_radio('otros', $tipo) ?>>
            <span class="tag">Otros</span>
          </label>

          <span class="opt-sep">Especifique:</span>

          <input
            type="text"
            name="tipo_anestesia_otro"
            id="tipo_anestesia_otro"
            value="<?= e($otro) ?>"
            class="box-input"
            style="width:260px;"
            placeholder="Ej: Bloqueo interescalénico, etc."
            <?= $disabled ?>
          >
        </div>
      </td>
    </tr>
  </tbody>
</table>

<script>
(function(){
  const canEdit = <?= empty($can_edit) ? 'false' : 'true' ?>;
  const otroInput = document.getElementById('tipo_anestesia_otro');

  function sync() {
    if (!otroInput) return;
    const sel = document.querySelector('input[name="tipo_anestesia"]:checked');
    const isOtros = sel && sel.value === 'otros';

    // Solo habilitar "Especifique" si escogió "Otros" y puede editar
    otroInput.disabled = !(isOtros && canEdit);

    // Si no es "Otros", limpiamos para que no guarde basura
    if (!isOtros) otroInput.value = '';
  }

  document.querySelectorAll('input[name="tipo_anestesia"]').forEach(r => {
    r.addEventListener('change', sync);
  });

  sync();
})();
</script>
