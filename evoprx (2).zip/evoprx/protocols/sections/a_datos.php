<?php
// protocols/sections/a_datos.php
// Carga directa desde BD (patients + establishments) y render estilo MSP con _ui.css

if (!function_exists('e')) {
  function e($v){ return htmlspecialchars((string)$v, ENT_QUOTES, 'UTF-8'); }
}

// Intentar asegurar $pdo (ajusta rutas si tu config.php está en otro lado)
if (!isset($pdo)) {
  $try1 = dirname(__DIR__, 2) . '/config.php'; // /evoprx/config.php (común)
  $try2 = dirname(__DIR__, 3) . '/config.php';
  if (file_exists($try1)) require_once $try1;
  elseif (file_exists($try2)) require_once $try2;
}

// Permisos edición (si no lo pasas, default: true para HC/archivo/nombres si quieres)
$canEdit = isset($canEdit) ? (bool)$canEdit : true;
$ro = $canEdit ? '' : 'readonly';
$dis = $canEdit ? '' : 'disabled';

// 1) Obtener patient_id
$patientId = 0;
if (isset($_GET['patient_id'])) $patientId = (int)$_GET['patient_id'];
elseif (isset($_POST['patient_id'])) $patientId = (int)$_POST['patient_id'];

// 2) Cargar paciente + establecimiento
$p = $p ?? [];
$est = $est ?? [];

if (empty($p) && $patientId > 0 && isset($pdo)) {
  $sql = "
    SELECT
      p.id,
      p.hc,
      p.cedula,
      p.primer_nombre,
      p.segundo_nombre,
      p.primer_apellido,
      p.segundo_apellido,
      p.sexo,
      p.fecha_nac,
      p.establishment_id,

      e.institucion_sistema,
      e.unicodigo,
      e.establecimiento_salud
    FROM patients p
    LEFT JOIN establishments e ON e.id = p.establishment_id
    WHERE p.id = :id
    LIMIT 1
  ";
  $st = $pdo->prepare($sql);
  $st->execute([':id' => $patientId]);
  $row = $st->fetch(PDO::FETCH_ASSOC);

  if ($row) {
    $p = [
      'id' => (int)$row['id'],
      'hc' => (string)($row['hc'] ?? ''),
      'cedula' => (string)($row['cedula'] ?? ''),
      'primer_nombre' => (string)($row['primer_nombre'] ?? ''),
      'segundo_nombre' => (string)($row['segundo_nombre'] ?? ''),
      'primer_apellido' => (string)($row['primer_apellido'] ?? ''),
      'segundo_apellido' => (string)($row['segundo_apellido'] ?? ''),
      'sexo' => (string)($row['sexo'] ?? ''),
      'fecha_nac' => (string)($row['fecha_nac'] ?? ''),
      'establishment_id' => $row['establishment_id'] !== null ? (int)$row['establishment_id'] : null,
    ];

    $est = [
      'institucion_sistema' => (string)($row['institucion_sistema'] ?? ''),
      'unicodigo' => (string)($row['unicodigo'] ?? ''),
      'establecimiento_salud' => (string)($row['establecimiento_salud'] ?? ''),
    ];
  }
}

// 3) Edad + Condición edad (H/D/M/A) desde fecha_nac
function calc_age_and_cond($fecha_nac): array {
  $fecha_nac = trim((string)$fecha_nac);
  if ($fecha_nac === '') return ['edad' => '', 'cond' => ''];

  try {
    $dob = new DateTime($fecha_nac);
    $now = new DateTime('now');
    $diff = $dob->diff($now);

    // edad numérica en "años" (como en formularios tradicionales)
    $edadAnios = (string)$diff->y;

    // Condición edad:
    // A: >= 1 año
    // M: < 1 año y >= 1 mes
    // D: < 1 mes y >= 1 día
    // H: < 1 día
    if ($diff->y >= 1) return ['edad' => $edadAnios, 'cond' => 'A'];
    if ($diff->m >= 1) return ['edad' => '0', 'cond' => 'M'];
    if ($diff->d >= 1) return ['edad' => '0', 'cond' => 'D'];
    return ['edad' => '0', 'cond' => 'H'];
  } catch (Throwable $e) {
    return ['edad' => '', 'cond' => ''];
  }
}

$calc = calc_age_and_cond($p['fecha_nac'] ?? '');
$edadYears = $calc['edad'];
$condEdad  = $calc['cond'];

// 4) Campos (solo los de la imagen)
$institucion = (string)($est['institucion_sistema'] ?? '');
$unicodigo   = (string)($est['unicodigo'] ?? '');
$establec    = (string)($est['establecimiento_salud'] ?? '');

$hc          = (string)($p['hc'] ?? '');
$archivo     = (string)($p['archivo'] ?? ''); // si no existe en BD, queda vacío (no rompe)
$pa          = (string)($p['primer_apellido'] ?? '');
$sa          = (string)($p['segundo_apellido'] ?? '');
$pn          = (string)($p['primer_nombre'] ?? '');
$sn          = (string)($p['segundo_nombre'] ?? '');
$sexo        = strtoupper(trim((string)($p['sexo'] ?? '')));

?>

<!-- A. DATOS -->
<div class="sec-bar">A. DATOS DE ESTABLECIMIENTO Y USUARIO / PACIENTE</div>

<!-- Hidden para que siempre viaje el patient_id -->
<input type="hidden" name="patient_id" value="<?= (int)($p['id'] ?? $patientId) ?>">

<table class="tbl">
  <colgroup>
    <col style="width:18%">
    <col style="width:10%">
    <col style="width:22%">
    <col style="width:30%">
    <col style="width:20%">
  </colgroup>
  <thead>
    <tr>
      <th>INSTITUCIÓN DEL SISTEMA</th>
      <th>UNICÓDIGO</th>
      <th>ESTABLECIMIENTO DE SALUD</th>
      <th>NÚMERO DE HISTORIA CLÍNICA ÚNICA</th>
      <th>NÚMERO DE ARCHIVO</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <td><input class="cell-input" value="<?= e($institucion) ?>" readonly></td>
      <td><input class="cell-input" value="<?= e($unicodigo) ?>" readonly></td>
      <td><input class="cell-input" value="<?= e($establec) ?>" readonly></td>
      <td><input name="hc" class="cell-input" value="<?= e($hc) ?>" <?= $ro ?>></td>
      <td><input name="archivo" class="cell-input" value="<?= e($archivo) ?>" <?= $ro ?>></td>
    </tr>
  </tbody>
</table>

<table class="tbl" style="border-top:0;">
  <colgroup>
    <col style="width:18%">
    <col style="width:18%">
    <col style="width:16%">
    <col style="width:22%">
    <col style="width:6%">
    <col style="width:6%">
    <col style="width:14%">
  </colgroup>
  <thead>
    <tr>
      <th>PRIMER APELLIDO</th>
      <th>SEGUNDO APELLIDO</th>
      <th>PRIMER NOMBRE</th>
      <th>SEGUNDO NOMBRE</th>
      <th>SEXO</th>
      <th>EDAD</th>
      <th>CONDICIÓN EDAD (MARCAR)</th>
    </tr>
  </thead>

  <tbody>
    <tr>
      <td><input name="primer_apellido" class="cell-input" value="<?= e($pa) ?>" <?= $ro ?>></td>
      <td><input name="segundo_apellido" class="cell-input" value="<?= e($sa) ?>" <?= $ro ?>></td>
      <td><input name="primer_nombre" class="cell-input" value="<?= e($pn) ?>" <?= $ro ?>></td>
      <td><input name="segundo_nombre" class="cell-input" value="<?= e($sn) ?>" <?= $ro ?>></td>

      <td class="center">
        <input name="sexo" class="cell-input center" value="<?= e($sexo) ?>" <?= $ro ?> style="text-transform:uppercase;">
      </td>

      <td class="center">
        <input class="cell-input center" value="<?= e($edadYears) ?>" readonly>
      </td>

      <td>
        <div style="display:flex; gap:12px; align-items:center; justify-content:space-between;">
          <?php
            $opts = ['H'=>'H','D'=>'D','M'=>'M','A'=>'A'];
            foreach ($opts as $val=>$lab):
              $id = 'condedad_'.$val.'_'.(int)($p['id'] ?? $patientId);
          ?>
            <label class="chk" for="<?= e($id) ?>" style="gap:4px;">
              <input
                id="<?= e($id) ?>"
                type="radio"
                name="cond_edad"
                value="<?= e($val) ?>"
                <?= ($condEdad === $val) ? 'checked' : '' ?>
                disabled
              >
              <span class="tag"><?= e($lab) ?></span>
            </label>
          <?php endforeach; ?>
        </div>
      </td>
    </tr>
  </tbody>
</table>
