<?php
// protocols/sections/c_procedimiento.php
// Requiere: $sp (array) con valores actuales del protocolo (o vacío)

$tipo       = (string)($sp['procedimiento_tipo'] ?? ''); // electiva|emergencia|urgencia
$proyectado = (string)($sp['proyectado'] ?? '');
$realizado  = (string)($sp['realizado'] ?? '');
?>

<table class="sp-table">
  <colgroup>
    <col style="width:55%">
    <col style="width:15%">
    <col style="width:10%">
    <col style="width:10%">
    <col style="width:10%">
  </colgroup>

  <thead>
    <tr>
      <th class="sp-head sp-head--blue">C. PROCEDIMIENTO</th>

      <th class="sp-head sp-head--green sp-center">
        <label class="sp-radio">
          <input type="radio" name="procedimiento_tipo" value="electiva" <?= $tipo==='electiva'?'checked':''; ?>>
          <span>Electiva</span>
        </label>
      </th>

      <th class="sp-head sp-head--green sp-center">
        <label class="sp-radio">
          <input type="radio" name="procedimiento_tipo" value="emergencia" <?= $tipo==='emergencia'?'checked':''; ?>>
          <span>Emergencia</span>
        </label>
      </th>

      <th class="sp-head sp-head--green sp-center">
        <label class="sp-radio">
          <input type="radio" name="procedimiento_tipo" value="urgencia" <?= $tipo==='urgencia'?'checked':''; ?>>
          <span>Urgencia</span>
        </label>
      </th>

      <th class="sp-head sp-head--green sp-center">&nbsp;</th>
    </tr>
  </thead>

  <tbody>
    <tr>
      <td class="sp-label sp-label--green">Proyectado:</td>
      <td colspan="4" class="sp-cell">
        <textarea name="proyectado" class="sp-input" rows="2"><?= e($proyectado) ?></textarea>
      </td>
    </tr>

    <tr>
      <td class="sp-label sp-label--green">Realizado:</td>
      <td colspan="4" class="sp-cell">
        <textarea name="realizado" class="sp-input" rows="2"><?= e($realizado) ?></textarea>
      </td>
    </tr>
  </tbody>
</table>