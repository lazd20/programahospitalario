<?php
// protocols/sections/d_equipo.php
// Requiere: $sp (array) y helper e() disponible

$cirujano_1         = (string)($sp['cirujano_1'] ?? '');
$cirujano_2         = (string)($sp['cirujano_2'] ?? '');
$primer_ayudante    = (string)($sp['primer_ayudante'] ?? '');
$segundo_ayudante   = (string)($sp['segundo_ayudante'] ?? '');
$tercer_ayudante    = (string)($sp['tercer_ayudante'] ?? '');
$anestesiologo      = (string)($sp['anestesiologo'] ?? '');
$ayudante_anestesia = (string)($sp['ayudante_anestesia'] ?? '');
$otros_integrantes  = (string)($sp['otros_integrantes'] ?? '');
$instrumentista     = (string)($sp['instrumentista'] ?? '');
$circulante         = (string)($sp['circulante'] ?? '');

// Opcional: datalist con usuarios (para autocompletar nombres)
$usersForDatalist = [];
try {
  if (isset($pdo)) {
    $stU = $pdo->query("SELECT id, nombre, apellido, rol FROM users ORDER BY apellido, nombre");
    $usersForDatalist = $stU ? $stU->fetchAll(PDO::FETCH_ASSOC) : [];
  }
} catch (Throwable $e) {
  $usersForDatalist = [];
}
?>

<section class="msp-section">
  <div class="msp-section__title">
    <div class="msp-letter">D.</div>
    <div class="msp-title-text">INTEGRANTES DEL EQUIPO QUIRÚRGICO</div>
  </div>

  <?php if (!empty($usersForDatalist)): ?>
    <datalist id="dl-users">
      <?php foreach ($usersForDatalist as $uu): 
        $nm = trim(((string)($uu['nombre'] ?? '')).' '.((string)($uu['apellido'] ?? '')));
        $rl = (string)($uu['rol'] ?? '');
      ?>
        <option value="<?= e($nm) ?>"><?= e($rl) ?></option>
      <?php endforeach; ?>
    </datalist>
  <?php endif; ?>

  <div class="msp-grid-2">
    <!-- Columna Izquierda -->
    <div class="msp-table">
      <div class="msp-row">
        <div class="msp-label">Cirujano 1:</div>
        <div class="msp-input">
          <input class="msp-field" name="cirujano_1" value="<?= e($cirujano_1) ?>"
                 list="<?= !empty($usersForDatalist) ? 'dl-users' : '' ?>" maxlength="255">
        </div>
      </div>

      <div class="msp-row">
        <div class="msp-label">Cirujano 2:</div>
        <div class="msp-input">
          <input class="msp-field" name="cirujano_2" value="<?= e($cirujano_2) ?>"
                 list="<?= !empty($usersForDatalist) ? 'dl-users' : '' ?>" maxlength="255">
        </div>
      </div>

      <div class="msp-row">
        <div class="msp-label">Primer Ayudante:</div>
        <div class="msp-input">
          <input class="msp-field" name="primer_ayudante" value="<?= e($primer_ayudante) ?>"
                 list="<?= !empty($usersForDatalist) ? 'dl-users' : '' ?>" maxlength="255">
        </div>
      </div>

      <div class="msp-row">
        <div class="msp-label">Segundo Ayudante:</div>
        <div class="msp-input">
          <input class="msp-field" name="segundo_ayudante" value="<?= e($segundo_ayudante) ?>"
                 list="<?= !empty($usersForDatalist) ? 'dl-users' : '' ?>" maxlength="255">
        </div>
      </div>

      <div class="msp-row">
        <div class="msp-label">Tercer Ayudante:</div>
        <div class="msp-input">
          <input class="msp-field" name="tercer_ayudante" value="<?= e($tercer_ayudante) ?>"
                 list="<?= !empty($usersForDatalist) ? 'dl-users' : '' ?>" maxlength="255">
        </div>
      </div>
    </div>

    <!-- Columna Derecha -->
    <div class="msp-table">
      <div class="msp-row">
        <div class="msp-label">Instrumentista:</div>
        <div class="msp-input">
          <input class="msp-field" name="instrumentista" value="<?= e($instrumentista) ?>"
                 list="<?= !empty($usersForDatalist) ? 'dl-users' : '' ?>" maxlength="255">
        </div>
      </div>

      <div class="msp-row">
        <div class="msp-label">Circulante:</div>
        <div class="msp-input">
          <input class="msp-field" name="circulante" value="<?= e($circulante) ?>"
                 list="<?= !empty($usersForDatalist) ? 'dl-users' : '' ?>" maxlength="255">
        </div>
      </div>

      <div class="msp-row">
        <div class="msp-label">Anestesiólogo/a:</div>
        <div class="msp-input">
          <input class="msp-field" name="anestesiologo" value="<?= e($anestesiologo) ?>"
                 list="<?= !empty($usersForDatalist) ? 'dl-users' : '' ?>" maxlength="255">
        </div>
      </div>

      <div class="msp-row">
        <div class="msp-label">Ayudante Anestesia:</div>
        <div class="msp-input">
          <input class="msp-field" name="ayudante_anestesia" value="<?= e($ayudante_anestesia) ?>"
                 list="<?= !empty($usersForDatalist) ? 'dl-users' : '' ?>" maxlength="255">
        </div>
      </div>

      <div class="msp-row msp-row--textarea">
        <div class="msp-label">Otros:</div>
        <div class="msp-input">
          <textarea class="msp-field msp-field--textarea" name="otros_integrantes" rows="2"
                    placeholder="Ej: perfusionista, técnico, etc."><?= e($otros_integrantes) ?></textarea>
        </div>
      </div>
    </div>
  </div>
</section>