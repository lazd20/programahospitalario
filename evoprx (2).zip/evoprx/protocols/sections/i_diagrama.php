<?php
// protocols/sections/i_diagrama.php
// Requiere: $sp (array), $can_edit (bool), $BASE (base url), helper e()

$sp = $sp ?? [];
$can_edit = isset($can_edit) ? (bool)$can_edit : true;

$diagramaPath = (string)($sp['diagrama_path'] ?? '');
$disabledAttr = $can_edit ? '' : 'disabled';
?>

<div class="sec-bar">I. DIAGRAMA DEL PROCEDIMIENTO</div>

<table class="tbl">
  <tr>
    <td class="lbl">Diagrama del procedimiento:</td>
    <td>
      <input type="hidden" name="diagrama_path_current" value="<?= e($diagramaPath) ?>">

      <div class="diagrama-zone" style="margin-top:4px;">
        <?php if ($diagramaPath): ?>
          <img id="diagramaPreview" src="<?= e($BASE) ?>/<?= e($diagramaPath) ?>" alt="Diagrama del procedimiento">
          <div id="diagramaPlaceholder" class="hint" style="display:none;">(Sin imagen cargada)</div>
        <?php else: ?>
          <div id="diagramaPlaceholder" class="hint">(Sin imagen cargada)</div>
          <img id="diagramaPreview" alt="Diagrama del procedimiento" style="display:none;">
        <?php endif; ?>
      </div>

      <div class="diagrama-actions">
        <label class="btn-mini" style="display:inline-flex; align-items:center; gap:8px;">
          <span>Subir imagen</span>
          <input
            type="file"
            name="diagrama_file"
            id="diagramaFile"
            accept="image/*"
            style="font-size:12px;"
            <?= $disabledAttr ?>
          >
        </label>

        <button type="button" class="btn-mini" id="diagramaClearBtn" <?= $disabledAttr ?>>
          Quitar imagen seleccionada
        </button>
      </div>

      <div style="font-size:10px;color:#666;margin-top:4px;">
        Recomendado: imagen nítida (JPG/PNG/WEBP).
      </div>
    </td>
  </tr>
</table>

<script>
(function(){
  const fileInput   = document.getElementById('diagramaFile');
  const preview     = document.getElementById('diagramaPreview');
  const placeholder = document.getElementById('diagramaPlaceholder');
  const clearBtn    = document.getElementById('diagramaClearBtn');

  if (!fileInput || !preview || !clearBtn) return;

  fileInput.addEventListener('change', function(){
    const f = this.files && this.files[0] ? this.files[0] : null;
    if (!f) return;

    const url = URL.createObjectURL(f);
    preview.src = url;
    preview.style.display = 'block';
    if (placeholder) placeholder.style.display = 'none';
  });

  clearBtn.addEventListener('click', function(){
    fileInput.value = '';
    // Solo quita la selección actual (no borra lo guardado en DB)
    const src = preview.getAttribute('src') || '';
    if (src.startsWith('blob:') || src === '') {
      preview.removeAttribute('src');
      preview.style.display = 'none';
      if (placeholder) placeholder.style.display = 'flex';
    }
  });
})();
</script>
