<?php
// /public_html/evoprx/residentes/tabla_altas.php
require_once __DIR__ . '/../auth.php';
require_login();
require_once __DIR__ . '/../helpers.php';

header('Content-Type: text/html; charset=utf-8');

function h($v) {
    return htmlspecialchars((string)$v, ENT_QUOTES | ENT_SUBSTITUTE, 'UTF-8');
}

try {
    $pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
    $pdo->exec("SET NAMES utf8mb4 COLLATE utf8mb4_unicode_ci");

    // Tablas con prefijo (hosp_)
    $T_INGRESOS      = t('ingresos');
    $T_USUARIOS      = t('usuarios');
    $T_HABITACIONES  = t('habitaciones');
    $T_TIPOS_INGRESO = t('tipos_ingreso');

    $sql = "
        SELECT
            i.*,
            u.username AS usuario_registro,
            hab.numero AS habitacion_numero,
            hab.descripcion AS habitacion_descripcion,
            ti.nombre AS tipo_ingreso_nombre,

            -- Nombre y apellido formateados (2 nombres / 2 apellidos)
            TRIM(CONCAT_WS(' ', NULLIF(i.nombre1,''), NULLIF(i.nombre2,''))) AS nombre_full,
            TRIM(CONCAT_WS(' ', NULLIF(i.apellido1,''), NULLIF(i.apellido2,''))) AS apellido_full

        FROM {$T_INGRESOS} i
        JOIN {$T_USUARIOS} u ON i.usuario_id = u.id
        LEFT JOIN {$T_HABITACIONES} hab ON i.habitacion_id = hab.id
        LEFT JOIN {$T_TIPOS_INGRESO} ti ON i.tipo_ingreso_id = ti.id
        WHERE i.estado IN ('alta', 'alta a petición')
        ORDER BY i.fecha_salida DESC
    ";

    $stmt = $pdo->query($sql);
    $altas = $stmt->fetchAll(PDO::FETCH_ASSOC);

} catch (Throwable $e) {
    die("❌ Error: " . h($e->getMessage()));
}
?>

<div class="table-responsive">
    <table class="table table-bordered table-striped table-hover align-middle">
        <thead class="table-dark text-center">
            <tr>
                <th>ID</th>
                <th>Nombre</th>
                <th>Apellido</th>
                <th>Cédula</th>
                <th>Fecha Entrada</th>
                <th>Fecha Salida</th>
                <th>Tratante</th>
                <th>Tipo Ingreso</th>
                <th>Habitación</th>
                <th>Estado</th>
                <th>Registrado por</th>
                <th>Acciones</th>
            </tr>
        </thead>
        <tbody>
            <?php if (empty($altas)): ?>
                <tr>
                    <td colspan="12" class="text-center text-muted py-4">No hay altas registradas.</td>
                </tr>
            <?php endif; ?>

            <?php foreach ($altas as $ingreso): ?>
                <?php
                    $nombre   = trim((string)($ingreso['nombre_full'] ?? ''));
                    $apellido = trim((string)($ingreso['apellido_full'] ?? ''));

                    // Fallback por si hay registros viejos sin nombre1/apellido1
                    if ($nombre === '' && !empty($ingreso['nombre'])) $nombre = (string)$ingreso['nombre'];
                    if ($apellido === '' && !empty($ingreso['apellido'])) $apellido = (string)$ingreso['apellido'];

                    $cedula = $ingreso['cedula'] ?? '';
                    $tipoIngreso = $ingreso['tipo_ingreso_nombre'] ?? '';

                    $estado = $ingreso['estado'] ?? 'alta';
                    $badgeClass = ($estado === 'alta') ? 'badge bg-success' : 'badge bg-info text-dark';
                ?>

                <tr>
                    <td class="text-center"><?= (int)$ingreso['id'] ?></td>

                    <td><?= $nombre !== '' ? h($nombre) : '<span class="text-muted">—</span>' ?></td>
                    <td><?= $apellido !== '' ? h($apellido) : '<span class="text-muted">—</span>' ?></td>

                    <td><?= $cedula !== '' ? h($cedula) : '<span class="text-muted">—</span>' ?></td>

                    <td class="text-center"><?= !empty($ingreso['fecha_entrada']) ? h($ingreso['fecha_entrada']) : '<span class="text-muted">—</span>' ?></td>
                    <td class="text-center"><?= !empty($ingreso['fecha_salida']) ? h($ingreso['fecha_salida']) : '<span class="text-muted">—</span>' ?></td>

                    <td><?= !empty($ingreso['tratante']) ? h($ingreso['tratante']) : '<span class="text-muted">—</span>' ?></td>

                    <td class="text-center">
                        <?= $tipoIngreso !== '' ? h($tipoIngreso) : '<span class="text-muted">—</span>' ?>
                    </td>

                    <td class="text-center">
                        <?php if (!empty($ingreso['habitacion_numero'])): ?>
                            <?= "Habitación " . h($ingreso['habitacion_numero']) . " - " . h($ingreso['habitacion_descripcion'] ?? '') ?>
                        <?php else: ?>
                            <span class="text-muted">Emergencia</span>
                        <?php endif; ?>
                    </td>

                    <td class="text-center">
                        <span class="<?= h($badgeClass) ?>"><?= h(ucfirst($estado)) ?></span>
                    </td>

                    <td class="text-center"><?= h($ingreso['usuario_registro'] ?? '') ?></td>

                    <td class="text-center">
                        <a href="membrete.php?id=<?= (int)$ingreso['id'] ?>" target="_blank" class="btn btn-sm btn-dark">🖨 Membrete</a>
                    </td>
                </tr>
            <?php endforeach; ?>
        </tbody>
    </table>
</div>