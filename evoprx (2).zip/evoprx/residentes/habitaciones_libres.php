<?php
require_once __DIR__ . '/../auth.php';
require_login();
require_once __DIR__ . '/../helpers.php';

date_default_timezone_set('America/Guayaquil');

try {
    $pdo->exec("SET NAMES utf8mb4 COLLATE utf8mb4_unicode_ci");

    $stmt = $pdo->query("
        SELECT id, numero
        FROM hosp_habitaciones
        WHERE estado = 'libre'
        ORDER BY numero ASC
    ");

    $habitaciones = $stmt->fetchAll(PDO::FETCH_ASSOC);

} catch (Throwable $e) {
    die("❌ Error: " . $e->getMessage());
}
?>

<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <title>Habitaciones Libres</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
</head>
<body class="bg-light">
<div class="container mt-5">
    <h2 class="text-primary mb-4">🛏️ Habitaciones Disponibles</h2>

    <?php if (empty($habitaciones)): ?>
        <div class="alert alert-info text-center">
            No hay habitaciones disponibles en este momento.
        </div>
    <?php else: ?>
        <table class="table table-bordered table-striped text-center align-middle">
            <thead class="table-dark">
                <tr>
                    <th>ID</th>
                    <th>Número</th>
                    <th>Estado</th>
                </tr>
            </thead>
            <tbody>
            <?php foreach ($habitaciones as $h): ?>
                <tr>
                    <td><?= (int)$h['id'] ?></td>
                    <td><?= htmlspecialchars($h['numero']) ?></td>
                    <td><span class="badge bg-success">Libre</span></td>
                </tr>
            <?php endforeach; ?>
            </tbody>
        </table>
    <?php endif; ?>

    <a href="<?= base_url('/residentes/panel_ingresos.php') ?>" class="btn btn-secondary mt-3">
        ⬅ Volver al panel
    </a>
</div>
</body>
</html>