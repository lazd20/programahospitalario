<?php
// /public_html/evoprx/residentes/dar_alta.php

require_once __DIR__ . '/../auth.php';
require_login();
require_once __DIR__ . '/../helpers.php';

header('Content-Type: text/html; charset=UTF-8');
date_default_timezone_set('America/Guayaquil');

global $pdo;

/* =========================
   Helpers
   ========================= */


function is_ajax_request(): bool {
  return !empty($_SERVER['HTTP_X_REQUESTED_WITH'])
    && strtolower($_SERVER['HTTP_X_REQUESTED_WITH']) === 'xmlhttprequest';
}

function joinParts($a, $b): string {
  $a = trim((string)$a);
  $b = trim((string)$b);
  $out = trim($a . ' ' . $b);
  return trim(preg_replace('/\s+/', ' ', $out));
}

function paciente_label(array $p): string {
  // Preferir columnas nuevas
  $n = joinParts(($p['nombre1'] ?? ''), ($p['nombre2'] ?? ''));
  $a = joinParts(($p['apellido1'] ?? ''), ($p['apellido2'] ?? ''));
  $full = trim(joinParts($n, $a));

  // Fallback esquema viejo
  if ($full === '') {
    $full = trim(joinParts(($p['nombre'] ?? ''), ($p['apellido'] ?? '')));
  }
  return $full !== '' ? $full : '��';
}

/* =========================
   Tablas (prefijo hosp_)
   ========================= */
$T_INGRESOS  = 'hosp_ingresos';
$T_HABIT     = 'hosp_habitaciones';
$T_AUDITORIA = 'hosp_altas_auditoria';

/* =========================
   Usuario / Roles
   ========================= */
$u = function_exists('current_user') ? current_user() : [];
$usuario_id = (int)($u['id'] ?? ($_SESSION['usuario_id'] ?? 0));

// Rol desde current_user() o sesi��n (compatibilidad)
$rol = (string)($u['rol'] ?? ($_SESSION['role'] ?? ''));

// Permisos: admin o editor
if (!in_array($rol, ['admin', 'editor'], true)) {
  if (is_ajax_request()) {
    http_response_code(403);
    echo "No tienes permiso.";
    exit;
  }
  echo "<script>alert('No tienes permiso para realizar esta acci��n.'); window.location.href='panel_ingresos.php';</script>";
  exit;
}

try {
  $pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
  $pdo->exec("SET NAMES utf8mb4 COLLATE utf8mb4_unicode_ci");
} catch (Throwable $e) {
  // no cr��tico
}

/* =========================
   POST: Registrar alta
   ========================= */
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
  $id           = isset($_POST['id']) ? (int)$_POST['id'] : 0;
  $fecha_salida = trim((string)($_POST['fecha_salida'] ?? ''));
  $estado       = trim((string)($_POST['estado'] ?? ''));

  if ($id <= 0 || $fecha_salida === '' || $estado === '') {
    if (is_ajax_request()) {
      http_response_code(400);
      echo "Datos incompletos.";
      exit;
    }
    if (function_exists('flash_set')) flash_set('error', 'Datos incompletos.');
    if (function_exists('redirect')) redirect(base_url('/residentes/panel_ingresos.php'));
    die("Datos incompletos.");
  }

  // Normalizar estados permitidos (evita valores raros)
  $estadoPermitido = ['alta', 'alta a petici��n'];
  if (!in_array($estado, $estadoPermitido, true)) {
    if (is_ajax_request()) {
      http_response_code(400);
      echo "Tipo de alta inv��lido.";
      exit;
    }
    if (function_exists('flash_set')) flash_set('error', 'Tipo de alta inv��lido.');
    if (function_exists('redirect')) redirect(base_url('/residentes/panel_ingresos.php'));
    die("Tipo de alta inv��lido.");
  }

  try {
    $pdo->beginTransaction();

    // 1) Leer ingreso + habitaci��n (y validar que exista)
    $st = $pdo->prepare("SELECT id, habitacion_id FROM {$T_INGRESOS} WHERE id = ? LIMIT 1");
    $st->execute([$id]);
    $row = $st->fetch(PDO::FETCH_ASSOC);

    if (!$row) {
      throw new Exception("El ingreso no existe.");
    }

    $habitacion_id = (int)($row['habitacion_id'] ?? 0);

    // 2) Actualizar ingreso (fecha_salida + estado)
    $upd = $pdo->prepare("UPDATE {$T_INGRESOS} SET fecha_salida = ?, estado = ? WHERE id = ? LIMIT 1");
    $upd->execute([$fecha_salida, $estado, $id]);

    // 3) Liberar habitaci��n (si ten��a)
    if ($habitacion_id > 0) {
      $pdo->prepare("UPDATE {$T_HABIT} SET estado = 'libre' WHERE id = ? LIMIT 1")->execute([$habitacion_id]);
    }

    // 4) Auditor��a (si la tabla existe y quieres registrar)
    // Nota: si la tabla no existe, comenta este bloque.
    $aud = $pdo->prepare("
      INSERT INTO {$T_AUDITORIA} (ingreso_id, usuario_id, fecha_alta, tipo_alta)
      VALUES (?, ?, ?, ?)
    ");
    $aud->execute([$id, $usuario_id, date('Y-m-d H:i:s'), $estado]);

    $pdo->commit();

    if (is_ajax_request()) {
      echo "OK";
      exit;
    }

    if (function_exists('flash_set')) flash_set('success', 'Alta registrada correctamente.');
    if (function_exists('redirect')) redirect(base_url('/residentes/panel_ingresos.php'));
    header("Location: panel_ingresos.php?ok=1");
    exit;

  } catch (Throwable $ex) {
    if ($pdo->inTransaction()) $pdo->rollBack();

    if (is_ajax_request()) {
      http_response_code(500);
      echo "Error al registrar alta: " . $ex->getMessage();
      exit;
    }

    if (function_exists('flash_set')) flash_set('error', 'Error al registrar alta: ' . $ex->getMessage());
    if (function_exists('redirect')) redirect(base_url('/residentes/panel_ingresos.php'));
    die("Error al registrar alta: " . e($ex->getMessage()));
  }
}

/* =========================
   GET: Mostrar formulario
   ========================= */
$id = isset($_GET['id']) ? (int)$_GET['id'] : 0;
if ($id <= 0) {
  http_response_code(400);
  die("ID no especificado.");
}

$stmt = $pdo->prepare("SELECT * FROM {$T_INGRESOS} WHERE id = ? LIMIT 1");
$stmt->execute([$id]);
$paciente = $stmt->fetch(PDO::FETCH_ASSOC);

if (!$paciente) {
  http_response_code(404);
  die("Paciente no encontrado.");
}

$flashes = function_exists('flash_get_all') ? flash_get_all() : [];
$nombrePaciente = paciente_label($paciente);
?>
<!DOCTYPE html>
<html lang="es">
<head>
  <meta charset="UTF-8">
  <title>Dar de Alta - Realmedic</title>
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
</head>
<body class="bg-light">
<div class="container mt-5">

  <?php foreach ($flashes as $type => $msg): ?>
    <div class="alert alert-<?= e($type === 'error' ? 'danger' : $type) ?>"><?= e($msg) ?></div>
  <?php endforeach; ?>

  <h3 class="mb-4">
    �0�2 Dar de alta al paciente:
    <?= e($nombrePaciente) ?>
    <small class="text-muted">(#<?= (int)$paciente['id'] ?>)</small>
  </h3>

  <form method="POST" autocomplete="off">
    <input type="hidden" name="id" value="<?= (int)$paciente['id'] ?>">

    <div class="mb-3">
      <label class="form-label">Fecha de salida:</label>
      <input type="date" name="fecha_salida" class="form-control" required value="<?= e(date('Y-m-d')) ?>">
      <small class="text-muted">Puede ajustar la fecha si corresponde.</small>
    </div>

    <div class="mb-3">
      <label class="form-label">Tipo de alta:</label>
      <select name="estado" class="form-select" required>
        <option value="alta">Alta</option>
        <option value="alta a petici��n">Alta a petici��n</option>
      </select>
    </div>

    <div class="d-flex gap-2">
      <button type="submit" class="btn btn-success">Registrar alta</button>
      <a href="<?= e(function_exists('base_url') ? base_url('/residentes/panel_ingresos.php') : 'panel_ingresos.php') ?>" class="btn btn-secondary">Cancelar</a>
    </div>
  </form>

</div>

<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>