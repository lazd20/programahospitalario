<?php
require_once __DIR__ . '/../auth.php';
require_login();
require_once __DIR__ . '/../helpers.php';

$u = current_user();
?>
<!DOCTYPE html>
<html lang="es">
<head>
  <meta charset="UTF-8">
  <title>Inicio - Sistema de Residentes Realmedic</title>
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
</head>
<body class="bg-light">

<nav class="navbar navbar-expand-lg navbar-dark bg-primary">
  <div class="container-fluid">
    <span class="navbar-text text-white">
      👤 Conectado como: <strong><?= e($u['username'] ?? '') ?></strong> (<?= e($u['rol'] ?? '') ?>)
    </span>
    <a href="<?= base_url('/auth/logout.php') ?>" class="btn btn-outline-light ms-auto">Cerrar sesión</a>
  </div>
</nav>

<div class="container mt-5">
  <div class="card shadow p-4">
    <h2 class="mb-4 text-primary">🏥 Sistema de Gestión de Ingresos - Realmedic</h2>

    <p class="lead">Bienvenido. Selecciona una opción:</p>

    <div class="d-grid gap-3 col-md-6 mx-auto">
      <a href="<?= base_url('/residentes/registrar.php') ?>" class="btn btn-outline-primary btn-lg">➕ Registrar nuevo ingreso</a>
      <a href="<?= base_url('/residentes/panel_ingresos.php') ?>" class="btn btn-outline-success btn-lg">📋 Ver panel de ingresos</a>

      <?php if (($u['rol'] ?? '') === 'admin'): ?>
        <a href="<?= base_url('/residentes/usuarios.php') ?>" class="btn btn-outline-warning btn-lg">👥 Gestión de usuarios</a>
      <?php endif; ?>
    </div>
  </div>
</div>

</body>
</html>