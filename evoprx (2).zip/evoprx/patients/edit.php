<?php
// patients/edit.php
require_once __DIR__ . '/../auth.php';
require_login();
require_once __DIR__ . '/../helpers.php';
require_once __DIR__ . '/../config.php';

$BASE = $GLOBALS['BASE_URL'] ?? '';
$u = current_user();

if (($u['rol'] ?? '') !== 'admin') {
  flash_set('error', 'No tienes permisos para editar pacientes.');
  redirect($BASE . '/patients/list.php');
}

$id = (int)($_GET['id'] ?? 0);
if ($id <= 0) {
  flash_set('error', 'Paciente inválido.');
  redirect($BASE . '/patients/list.php');
}

function clean_str($v): string {
  $v = trim((string)$v);
  $v = preg_replace('/\s+/u', ' ', $v);
  return $v ?? '';
}
function join_parts(string $a, string $b): string {
  $a = clean_str($a);
  $b = clean_str($b);
  if ($a !== '' && $b !== '') return $a . ' ' . $b;
  return $a !== '' ? $a : $b;
}
function get_default_establishment(PDO $pdo): array {
  $st = $pdo->prepare("SELECT id, establecimiento_salud FROM establishments WHERE activo=1 ORDER BY id ASC LIMIT 1");
  $st->execute();
  $row = $st->fetch(PDO::FETCH_ASSOC);
  if ($row && (int)$row['id'] > 0) return [(int)$row['id'], (string)$row['establecimiento_salud']];
  $name = 'CLINICA REALMEDIC';
  $ins = $pdo->prepare("INSERT INTO establishments (establecimiento_salud, activo) VALUES (?, 1)");
  $ins->execute([$name]);
  return [(int)$pdo->lastInsertId(), $name];
}

$st = $pdo->prepare("SELECT * FROM patients WHERE id=? LIMIT 1");
$st->execute([$id]);
$p = $st->fetch(PDO::FETCH_ASSOC);
if (!$p) {
  flash_set('error', 'Paciente no encontrado.');
  redirect($BASE . '/patients/list.php');
}

[$defaultEstabId, $defaultEstabName] = get_default_establishment($pdo);
$estabId = (int)($p['establishment_id'] ?? 0);
$estabName = clean_str($p['establecimiento'] ?? '');
if ($estabId <= 0) $estabId = $defaultEstabId;
if ($estabName === '') $estabName = $defaultEstabName;

$errors = [];
$old = [
  'hc' => clean_str($p['hc'] ?? ''),
  'cedula' => clean_str($p['cedula'] ?? ''),
  'primer_nombre' => clean_str($p['primer_nombre'] ?? ''),
  'segundo_nombre' => clean_str($p['segundo_nombre'] ?? ''),
  'primer_apellido' => clean_str($p['primer_apellido'] ?? ''),
  'segundo_apellido' => clean_str($p['segundo_apellido'] ?? ''),
  'sexo' => clean_str($p['sexo'] ?? ''),
  'fecha_nac' => clean_str($p['fecha_nac'] ?? ''),
];

// Si vienen vacíos los campos normalizados (pacientes antiguos), intentamos derivar desde nombres/apellidos
if ($old['primer_nombre'] === '' && clean_str($p['nombres'] ?? '') !== '') {
  $parts = preg_split('/\s+/u', clean_str($p['nombres'] ?? ''), 2);
  $old['primer_nombre'] = $parts[0] ?? '';
  $old['segundo_nombre'] = $parts[1] ?? '';
}
if ($old['primer_apellido'] === '' && clean_str($p['apellidos'] ?? '') !== '') {
  $parts = preg_split('/\s+/u', clean_str($p['apellidos'] ?? ''), 2);
  $old['primer_apellido'] = $parts[0] ?? '';
  $old['segundo_apellido'] = $parts[1] ?? '';
}

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
  $old['hc'] = clean_str($_POST['hc'] ?? '');
  $old['cedula'] = clean_str($_POST['cedula'] ?? '');
  $old['primer_nombre'] = clean_str($_POST['primer_nombre'] ?? '');
  $old['segundo_nombre'] = clean_str($_POST['segundo_nombre'] ?? '');
  $old['primer_apellido'] = clean_str($_POST['primer_apellido'] ?? '');
  $old['segundo_apellido'] = clean_str($_POST['segundo_apellido'] ?? '');
  $old['sexo'] = clean_str($_POST['sexo'] ?? '');
  $old['fecha_nac'] = clean_str($_POST['fecha_nac'] ?? '');

  if ($old['hc'] === '') $errors[] = 'La historia clínica (HC) es obligatoria.';
  if ($old['cedula'] === '') $errors[] = 'La cédula es obligatoria.';
  if ($old['primer_nombre'] === '') $errors[] = 'El primer nombre es obligatorio.';
  if ($old['primer_apellido'] === '') $errors[] = 'El primer apellido es obligatorio.';

  if ($old['fecha_nac'] !== '' && !preg_match('/^\d{4}-\d{2}-\d{2}$/', $old['fecha_nac'])) {
    $errors[] = 'La fecha de nacimiento debe tener el formato YYYY-MM-DD.';
  }

  $nombres_unidos = join_parts($old['primer_nombre'], $old['segundo_nombre']);
  $apellidos_unidos = join_parts($old['primer_apellido'], $old['segundo_apellido']);

  if (!$errors) {
    // Evitar duplicados con otros registros
    $chk = $pdo->prepare("SELECT id FROM patients WHERE id<>? AND ((cedula = ? AND cedula <> '') OR (hc = ? AND hc <> '')) LIMIT 1");
    $chk->execute([$id, $old['cedula'], $old['hc']]);
    $exists = (int)($chk->fetchColumn() ?: 0);
    if ($exists > 0) {
      $errors[] = 'Ya existe otro paciente con esa cédula o historia clínica.';
    }
  }

  if (!$errors) {
    $sql = "UPDATE patients SET
              establishment_id=?,
              establecimiento=?,
              hc=?,
              cedula=?,
              nombres=?,
              apellidos=?,
              primer_nombre=?,
              segundo_nombre=?,
              primer_apellido=?,
              segundo_apellido=?,
              sexo=?,
              fecha_nac=?
            WHERE id=? LIMIT 1";

    $stU = $pdo->prepare($sql);
    $stU->execute([
      $estabId,
      $estabName,
      $old['hc'],
      $old['cedula'],
      $nombres_unidos,
      $apellidos_unidos,
      $old['primer_nombre'],
      $old['segundo_nombre'] !== '' ? $old['segundo_nombre'] : null,
      $old['primer_apellido'],
      $old['segundo_apellido'] !== '' ? $old['segundo_apellido'] : null,
      $old['sexo'] !== '' ? $old['sexo'] : null,
      $old['fecha_nac'] !== '' ? $old['fecha_nac'] : null,
      $id,
    ]);

    flash_set('success', 'Paciente actualizado correctamente.');
    redirect($BASE . '/patients/view.php?id=' . $id);
  }
}
?>
<!doctype html>
<html lang="es">
<head>
  <meta charset="utf-8" />
  <meta name="viewport" content="width=device-width, initial-scale=1" />
  <title>Editar paciente</title>
  <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
</head>
<body>
<?php include __DIR__ . '/../partials/navbar.php'; ?>
<div class="container py-4">
  <?php include __DIR__ . '/../partials/flash.php'; ?>

  <div class="d-flex align-items-center justify-content-between mb-3">
    <h4 class="mb-0">Editar paciente</h4>
    <a class="btn btn-outline-secondary" href="<?= e($BASE) ?>/patients/view.php?id=<?= (int)$id ?>">Volver</a>
  </div>

  <?php if ($errors): ?>
    <div class="alert alert-danger">
      <ul class="mb-0">
        <?php foreach ($errors as $er): ?>
          <li><?= e($er) ?></li>
        <?php endforeach; ?>
      </ul>
    </div>
  <?php endif; ?>

  <div class="card shadow-sm">
    <div class="card-body">
      <div class="mb-3">
        <label class="form-label">Establecimiento</label>
        <input class="form-control" value="<?= e($estabName) ?>" disabled>
        <div class="form-text">Por ahora se mantiene fijo (por defecto: <?= e($defaultEstabName) ?>).</div>
      </div>

      <form method="post" class="row g-3" autocomplete="off">
        <div class="col-md-6">
          <label class="form-label">Historia clínica (HC) *</label>
          <input name="hc" class="form-control" value="<?= e($old['hc']) ?>" required>
        </div>
        <div class="col-md-6">
          <label class="form-label">Cédula *</label>
          <input name="cedula" class="form-control" value="<?= e($old['cedula']) ?>" required>
        </div>

        <div class="col-md-6">
          <label class="form-label">Primer nombre *</label>
          <input name="primer_nombre" class="form-control" value="<?= e($old['primer_nombre']) ?>" required>
        </div>
        <div class="col-md-6">
          <label class="form-label">Segundo nombre</label>
          <input name="segundo_nombre" class="form-control" value="<?= e($old['segundo_nombre']) ?>">
        </div>

        <div class="col-md-6">
          <label class="form-label">Primer apellido *</label>
          <input name="primer_apellido" class="form-control" value="<?= e($old['primer_apellido']) ?>" required>
        </div>
        <div class="col-md-6">
          <label class="form-label">Segundo apellido</label>
          <input name="segundo_apellido" class="form-control" value="<?= e($old['segundo_apellido']) ?>">
        </div>

        <div class="col-md-6">
          <label class="form-label">Sexo</label>
          <select name="sexo" class="form-select">
            <option value="" <?= $old['sexo']===''?'selected':'' ?>>--</option>
            <option value="M" <?= $old['sexo']==='M'?'selected':'' ?>>M</option>
            <option value="F" <?= $old['sexo']==='F'?'selected':'' ?>>F</option>
          </select>
        </div>
        <div class="col-md-6">
          <label class="form-label">Fecha de nacimiento</label>
          <input type="date" name="fecha_nac" class="form-control" value="<?= e($old['fecha_nac']) ?>">
        </div>

        <div class="col-12 d-flex gap-2">
          <button class="btn btn-primary" type="submit">Guardar cambios</button>
          <a class="btn btn-outline-secondary" href="<?= e($BASE) ?>/patients/view.php?id=<?= (int)$id ?>">Cancelar</a>
        </div>
      </form>

    </div>
  </div>
</div>
</body>
</html>
