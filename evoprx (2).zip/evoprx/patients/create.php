<?php
// patients/create.php
require_once __DIR__ . '/../auth.php';
require_login();
require_once __DIR__ . '/../helpers.php';

$BASE = $GLOBALS['BASE_URL'] ?? '';
$u = current_user();

$errors = [];
$success = null;

// =====================
// 1) Establecimiento por defecto
// =====================
$defaultEstName = 'CLINICA REALMEDIC';

// Buscar establishment activo por nombre; si no existe, crear uno mínimo
$stE = $pdo->prepare("SELECT id, establecimiento_salud FROM establishments WHERE activo=1 AND establecimiento_salud = ? LIMIT 1");
$stE->execute([$defaultEstName]);
$defaultEst = $stE->fetch();

if (!$defaultEst) {
  // Si no existe, lo creamos con lo mínimo para que no rompa el flujo
  $insE = $pdo->prepare("INSERT INTO establishments (establecimiento_salud, activo) VALUES (?, 1)");
  $insE->execute([$defaultEstName]);

  $defaultEst = [
    'id' => (int)$pdo->lastInsertId(),
    'establecimiento_salud' => $defaultEstName
  ];
}

$establishment_id = (int)$defaultEst['id'];
$establecimiento_text = (string)$defaultEst['establecimiento_salud'];

// =====================
// 2) Helpers
// =====================
function norm_str($s) {
  $s = trim((string)$s);
  // Quita dobles espacios
  $s = preg_replace('/\s+/', ' ', $s);
  return $s;
}
function join_names($a, $b) {
  $a = norm_str($a);
  $b = norm_str($b);
  return trim($a . ' ' . $b);
}

// =====================
// 3) POST
// =====================
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
  $hc = norm_str($_POST['hc'] ?? '');
  $cedula = norm_str($_POST['cedula'] ?? '');

  $primer_nombre = norm_str($_POST['primer_nombre'] ?? '');
  $segundo_nombre = norm_str($_POST['segundo_nombre'] ?? '');

  $primer_apellido = norm_str($_POST['primer_apellido'] ?? '');
  $segundo_apellido = norm_str($_POST['segundo_apellido'] ?? '');

  $sexo = norm_str($_POST['sexo'] ?? '');
  $fecha_nac = norm_str($_POST['fecha_nac'] ?? '');

  // Validaciones mínimas (sin complicarte el sistema)
  if ($hc === '') $errors[] = 'La Historia Clínica (HC) es obligatoria.';
  if ($cedula === '') $errors[] = 'La cédula es obligatoria.';
  if ($primer_nombre === '') $errors[] = 'El primer nombre es obligatorio.';
  if ($primer_apellido === '') $errors[] = 'El primer apellido es obligatorio.';

  // Validar fecha (si viene)
  if ($fecha_nac !== '' && !preg_match('/^\d{4}-\d{2}-\d{2}$/', $fecha_nac)) {
    $errors[] = 'La fecha de nacimiento debe tener formato YYYY-MM-DD.';
  }

  // Construir campos legacy (nombres/apellidos)
  $nombres = join_names($primer_nombre, $segundo_nombre);
  $apellidos = join_names($primer_apellido, $segundo_apellido);

  // Si por alguna razón quedó vacío (por espacios), reforzamos
  if ($nombres === '') $errors[] = 'El nombre no puede quedar vacío.';
  if ($apellidos === '') $errors[] = 'El apellido no puede quedar vacío.';

  // Guardar
  if (!$errors) {
    try {
      $pdo->beginTransaction();

      // Opcional: evitar duplicados de hc o cédula (si quieres estricta)
      // Aquí solo avisamos si ya existe
      $chk = $pdo->prepare("SELECT id FROM patients WHERE (hc = ? AND hc IS NOT NULL) OR (cedula = ? AND cedula IS NOT NULL) LIMIT 1");
      $chk->execute([$hc, $cedula]);
      $exists = $chk->fetchColumn();
      if ($exists) {
        $pdo->rollBack();
        $errors[] = 'Ya existe un paciente con esa HC o esa cédula.';
      } else {
        $ins = $pdo->prepare("
          INSERT INTO patients
            (establishment_id, establecimiento, hc, cedula,
             nombres, apellidos,
             primer_nombre, segundo_nombre,
             primer_apellido, segundo_apellido,
             sexo, fecha_nac)
          VALUES
            (?, ?, ?, ?,
             ?, ?,
             ?, ?,
             ?, ?,
             ?, ?)
        ");

        $ins->execute([
          $establishment_id,
          $establecimiento_text,
          $hc,
          $cedula,
          $nombres,
          $apellidos,
          $primer_nombre,
          ($segundo_nombre !== '' ? $segundo_nombre : null),
          $primer_apellido,
          ($segundo_apellido !== '' ? $segundo_apellido : null),
          ($sexo !== '' ? $sexo : null),
          ($fecha_nac !== '' ? $fecha_nac : null),
        ]);

        $newId = (int)$pdo->lastInsertId();

        $pdo->commit();
        flash_set('success', 'Paciente creado correctamente.');
        redirect($BASE . '/patients/view.php?id=' . $newId);
      }
    } catch (Throwable $e) {
      if ($pdo->inTransaction()) $pdo->rollBack();
      $errors[] = 'Error al guardar: ' . $e->getMessage();
    }
  }
}

// Para repoblar inputs si hubo error
$old = function($key, $default='') {
  return isset($_POST[$key]) ? (string)$_POST[$key] : (string)$default;
};
?>
<!doctype html>
<html lang="es">
<head>
  <meta charset="utf-8" />
  <meta name="viewport" content="width=device-width, initial-scale=1" />
  <title>Crear paciente</title>
  <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
</head>
<body>

<?php include __DIR__ . '/../partials/navbar.php'; ?>

<div class="container py-4">
  <?php include __DIR__ . '/../partials/flash.php'; ?>

  <div class="d-flex align-items-center justify-content-between mb-3">
    <h4 class="m-0">Crear paciente</h4>
    <a class="btn btn-outline-secondary" href="<?= e($BASE) ?>/patients/list.php">Volver</a>
  </div>

  <?php if (!empty($errors)): ?>
    <div class="alert alert-danger">
      <b>Revisa lo siguiente:</b>
      <ul class="mb-0">
        <?php foreach ($errors as $er): ?>
          <li><?= e($er) ?></li>
        <?php endforeach; ?>
      </ul>
    </div>
  <?php endif; ?>

  <div class="card">
    <div class="card-body">
      <form method="post" autocomplete="off">

        <div class="row g-3">
          <div class="col-12">
            <label class="form-label">Establecimiento (por defecto)</label>
            <input type="text" class="form-control" value="<?= e($establecimiento_text) ?>" disabled>
            <div class="form-text">Se asigna automáticamente al establecimiento activo “<?= e($defaultEstName) ?>”.</div>
          </div>

          <div class="col-md-6">
            <label class="form-label">Historia Clínica (HC)</label>
            <input type="text" name="hc" class="form-control" required value="<?= e($old('hc')) ?>">
          </div>

          <div class="col-md-6">
            <label class="form-label">Cédula</label>
            <input type="text" name="cedula" class="form-control" required value="<?= e($old('cedula')) ?>">
          </div>

          <div class="col-md-6">
            <label class="form-label">Primer nombre</label>
            <input type="text" name="primer_nombre" class="form-control" required value="<?= e($old('primer_nombre')) ?>">
          </div>

          <div class="col-md-6">
            <label class="form-label">Segundo nombre (opcional)</label>
            <input type="text" name="segundo_nombre" class="form-control" value="<?= e($old('segundo_nombre')) ?>">
          </div>

          <div class="col-md-6">
            <label class="form-label">Primer apellido</label>
            <input type="text" name="primer_apellido" class="form-control" required value="<?= e($old('primer_apellido')) ?>">
          </div>

          <div class="col-md-6">
            <label class="form-label">Segundo apellido (opcional)</label>
            <input type="text" name="segundo_apellido" class="form-control" value="<?= e($old('segundo_apellido')) ?>">
          </div>

          <div class="col-md-4">
            <label class="form-label">Sexo</label>
            <select name="sexo" class="form-select">
              <?php $sx = $old('sexo'); ?>
              <option value="" <?= $sx===''?'selected':''; ?>>—</option>
              <option value="M" <?= $sx==='M'?'selected':''; ?>>M</option>
              <option value="F" <?= $sx==='F'?'selected':''; ?>>F</option>
              <option value="Otro" <?= $sx==='Otro'?'selected':''; ?>>Otro</option>
            </select>
          </div>

          <div class="col-md-4">
            <label class="form-label">Fecha de nacimiento</label>
            <input type="date" name="fecha_nac" class="form-control" value="<?= e($old('fecha_nac')) ?>">
          </div>
        </div>

        <div class="mt-4 d-flex gap-2">
          <button class="btn btn-primary" type="submit">Guardar</button>
          <a class="btn btn-outline-secondary" href="<?= e($BASE) ?>/patients/list.php">Cancelar</a>
        </div>

      </form>
    </div>
  </div>

</div>

</body>
</html>
