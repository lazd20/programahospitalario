<?php
require_once __DIR__ . '/../auth.php';
require_login();
require_once __DIR__ . '/../helpers.php';

$BASE = $GLOBALS['BASE_URL'] ?? '';
$u = current_user();

$q = trim((string)($_GET['q'] ?? ''));

// ====== Construir query según rol ======
$params = [];
$whereQ = '';
if ($q !== '') {
  $whereQ = " AND (p.hc LIKE ? OR p.cedula LIKE ? OR p.nombres LIKE ? OR p.apellidos LIKE ?) ";
  $like = "%{$q}%";
}

if ($u['rol'] === 'admin') {

  $sql = "SELECT p.*
          FROM patients p
          WHERE 1=1 " . ($whereQ ? $whereQ : "") . "
          ORDER BY p.apellidos, p.nombres";

  if ($whereQ) $params = [$like, $like, $like, $like];

} elseif ($u['rol'] === 'especialista') {

  $sql = "SELECT p.*
          FROM patients p
          INNER JOIN patient_doctors pd ON pd.patient_id = p.id
          WHERE pd.doctor_user_id = ? " . ($whereQ ? $whereQ : "") . "
          ORDER BY p.apellidos, p.nombres";

  $params = [$u['id']];
  if ($whereQ) $params = array_merge($params, [$like, $like, $like, $like]);

} else { // residente

  $sql = "SELECT p.*
          FROM patients p
          INNER JOIN resident_patients rp ON rp.patient_id = p.id
          WHERE rp.resident_user_id = ? " . ($whereQ ? $whereQ : "") . "
          ORDER BY p.apellidos, p.nombres";

  $params = [$u['id']];
  if ($whereQ) $params = array_merge($params, [$like, $like, $like, $like]);
}

// Ejecutar
$st = $pdo->prepare($sql);
$st->execute($params);
$rows = $st->fetchAll();

// Para mostrar tratante (opcional y útil)
$doctorMap = [];
if ($rows) {
  $ids = array_map(fn($r) => (int)$r['id'], $rows);
  $placeholders = implode(',', array_fill(0, count($ids), '?'));

  $st2 = $pdo->prepare("
    SELECT pd.patient_id, u.nombre, u.apellido
    FROM patient_doctors pd
    INNER JOIN users u ON u.id = pd.doctor_user_id
    WHERE pd.patient_id IN ($placeholders)
  ");
  $st2->execute($ids);
  foreach ($st2->fetchAll() as $d) {
    $doctorMap[(int)$d['patient_id']] = trim($d['apellido'] . ' ' . $d['nombre']);
  }
}
?>
<!doctype html>
<html lang="es">
<head>
  <meta charset="utf-8" />
  <meta name="viewport" content="width=device-width, initial-scale=1" />
  <title>Pacientes | Evo/Prx</title>
  <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
</head>
<body>
<?php include __DIR__ . '/../partials/navbar.php'; ?>

<div class="container py-4">
  <div class="d-flex flex-column flex-md-row justify-content-between align-items-md-center gap-2 mb-3">
    <div>
      <h4 class="mb-0">Pacientes</h4>
      <div class="text-muted small">
        <?php if ($u['rol'] === 'admin'): ?>
          Todos los pacientes
        <?php elseif ($u['rol'] === 'especialista'): ?>
          Mis pacientes (tratante)
        <?php else: ?>
          Mis pacientes (asignados como residente)
        <?php endif; ?>
      </div>
    </div>

    <?php if ($u['rol'] === 'admin'): ?>
      <a class="btn btn-primary" href="<?= e($BASE) ?>/patients/create.php">+ Nuevo</a>
    <?php endif; ?>
  </div>

  <?php include __DIR__ . '/../partials/flash.php'; ?>

  <div class="card mb-3">
    <div class="card-body">
      <form class="row g-2" method="get">
        <div class="col-md-8">
          <input class="form-control" name="q" value="<?= e($q) ?>" placeholder="Buscar por HC, cédula, nombres o apellidos...">
        </div>
        <div class="col-md-4 d-flex gap-2">
          <button class="btn btn-outline-primary w-100">Buscar</button>
          <a class="btn btn-outline-secondary w-100" href="<?= e($BASE) ?>/patients/list.php">Limpiar</a>
        </div>
      </form>
    </div>
  </div>

  <div class="table-responsive">
    <table class="table table-striped align-middle">
      <thead>
        <tr>
          <th>ID</th>
          <th>HC</th>
          <th>Paciente</th>
          <th>Cédula</th>
          <th>Tratante</th>
          <th class="text-end">Acciones</th>
        </tr>
      </thead>
      <tbody>
        <?php if (!$rows): ?>
          <tr>
            <td colspan="6" class="text-center text-muted py-4">No hay pacientes para mostrar.</td>
          </tr>
        <?php endif; ?>

        <?php foreach ($rows as $r): ?>
          <?php $pid = (int)$r['id']; ?>
          <tr>
            <td><?= $pid ?></td>
            <td><?= e((string)($r['hc'] ?? '')) ?></td>
            <td><?= e(trim(($r['apellidos'] ?? '') . ' ' . ($r['nombres'] ?? ''))) ?></td>
            <td><?= e((string)($r['cedula'] ?? '')) ?></td>
            <td><?= e($doctorMap[$pid] ?? '—') ?></td>
            <td class="text-end text-nowrap">
              <a class="btn btn-sm btn-outline-primary"
                 href="<?= e($BASE) ?>/print/patient_sheet.php?id=<?= $pid ?>">
                Hoja
              </a>
              <a class="btn btn-sm btn-outline-secondary"
                 target="_blank"
                 href="<?= e($BASE) ?>/print/patient_print.php?id=<?= $pid ?>">
                Imprimir
              </a>

              <?php if ($u['rol'] === 'admin'): ?>
                <a class="btn btn-sm btn-outline-warning" href="<?= e($BASE) ?>/patients/edit.php?id=<?= $pid ?>">Editar</a>
                <a class="btn btn-sm btn-outline-danger" href="<?= e($BASE) ?>/patients/delete.php?id=<?= $pid ?>">Eliminar</a>
              <?php endif; ?>
            </td>
          </tr>
        <?php endforeach; ?>
      </tbody>
    </table>
  </div>
</div>

<?php include __DIR__ . '/../partials/footer.php'; ?>
</body>
</html>
