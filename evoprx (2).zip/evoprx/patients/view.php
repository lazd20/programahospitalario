<?php
// patients/view.php
require_once __DIR__ . '/../auth.php';
require_login();
require_once __DIR__ . '/../helpers.php';

$BASE = rtrim($GLOBALS['BASE_URL'] ?? '', '/');
$u = current_user();

$patient_id = (int)($_GET['id'] ?? 0);
if ($patient_id <= 0) {
  flash_set('error', 'Paciente inválido.');
  redirect($BASE . '/patients/list.php');
}

/* =========================
   Cargar paciente
========================= */
$stP = $pdo->prepare("SELECT * FROM patients WHERE id=? LIMIT 1");
$stP->execute([$patient_id]);
$p = $stP->fetch();

if (!$p) {
  flash_set('error', 'Paciente no encontrado.');
  redirect($BASE . '/patients/list.php');
}

/* =========================
   Permisos (mismo criterio que usas)
   - admin: todo
   - especialista: si está asignado en patient_doctors
   - residente: si está asignado en resident_patients (solo ver)
========================= */
$rol = (string)($u['rol'] ?? '');
$isAdmin = ($rol === 'admin');

$isAssignedDoctor = false;
$isAssignedResident = false;

if (!$isAdmin) {
  if ($rol === 'especialista') {
    $chk = $pdo->prepare("SELECT 1 FROM patient_doctors WHERE patient_id=? AND doctor_user_id=? LIMIT 1");
    $chk->execute([$patient_id, (int)$u['id']]);
    $isAssignedDoctor = (bool)$chk->fetchColumn();
    if (!$isAssignedDoctor) {
      flash_set('error', 'No tienes acceso a este paciente.');
      redirect($BASE . '/patients/list.php');
    }
  } else { // residente (y cualquier rol no-admin no-especialista lo tratamos como residente)
    $chk = $pdo->prepare("SELECT 1 FROM resident_patients WHERE patient_id=? AND resident_user_id=? LIMIT 1");
    $chk->execute([$patient_id, (int)$u['id']]);
    $isAssignedResident = (bool)$chk->fetchColumn();
    if (!$isAssignedResident) {
      flash_set('error', 'No tienes acceso a este paciente.');
      redirect($BASE . '/patients/list.php');
    }
  }
} else {
  $isAssignedDoctor = true;   // admin puede actuar como doctor
  $isAssignedResident = true; // admin ve todo
}

/* =========================
   Permisos específicos por módulo
========================= */
$canViewClinical = $isAdmin || $isAssignedDoctor || $isAssignedResident; // ver evoluciones/prescripciones
$canEditClinical = $isAdmin || $isAssignedDoctor; // crear/editar encounter

$canViewProtocol = $canViewClinical;              // ver protocolo
$canEditProtocol = $isAdmin || $isAssignedDoctor; // llenar/editar protocolo

/* =========================
   Datos auxiliares / presentación
========================= */
$fullName = trim(($p['apellidos'] ?? '') . ' ' . ($p['nombres'] ?? ''));
$hc = (string)($p['hc'] ?? '');
$cedula = (string)($p['cedula'] ?? '');
$sexo = (string)($p['sexo'] ?? '');
$fechaNac = (string)($p['fecha_nac'] ?? '');
$establecimiento = (string)($p['establecimiento'] ?? '');

/* =========================
   Protocolo quirúrgico (último)
   Tabla: surgical_protocols
========================= */
$protocol = null;
try {
  $stPr = $pdo->prepare("
    SELECT id, patient_id, author_user_id, created_at, updated_at
    FROM surgical_protocols
    WHERE patient_id = ?
    ORDER BY created_at DESC, id DESC
    LIMIT 1
  ");
  $stPr->execute([$patient_id]);
  $protocol = $stPr->fetch();
} catch (Throwable $e) {
  // Si aún no existe la tabla, no rompemos la vista.
  $protocol = null;
}

$protocolId = (int)($protocol['id'] ?? 0);

include __DIR__ . '/../partials/navbar.php';
?>
<!doctype html>
<html lang="es">
<head>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <title>Paciente | <?= e($fullName) ?></title>
  <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
</head>
<body>

<div class="container py-4">

  <?php include __DIR__ . '/../partials/flash.php'; ?>

  <div class="d-flex align-items-center justify-content-between flex-wrap gap-2 mb-3">
    <div>
      <h3 class="mb-0"><?= e($fullName) ?></h3>
      <div class="text-muted">
        <?= $hc !== '' ? 'HC: <b>'.e($hc).'</b>' : '' ?>
        <?= $cedula !== '' ? ' &nbsp;|&nbsp; Cédula: <b>'.e($cedula).'</b>' : '' ?>
        <?= $sexo !== '' ? ' &nbsp;|&nbsp; Sexo: <b>'.e($sexo).'</b>' : '' ?>
        <?= $fechaNac !== '' ? ' &nbsp;|&nbsp; F. Nac: <b>'.e($fechaNac).'</b>' : '' ?>
      </div>
      <?php if ($establecimiento !== ''): ?>
        <div class="text-muted small">Establecimiento: <?= e($establecimiento) ?></div>
      <?php endif; ?>
    </div>

    <div class="d-flex gap-2">
      <a class="btn btn-outline-secondary" href="<?= e($BASE) ?>/patients/list.php">Volver</a>
      <?php if ($isAdmin): ?>
        <a class="btn btn-outline-primary" href="<?= e($BASE) ?>/patients/edit.php?id=<?= (int)$patient_id ?>">Editar ficha</a>
      <?php endif; ?>
    </div>
  </div>

  <div class="row g-3">

    <!-- =========================
         EVOLUCIÓN + PRESCRIPCIÓN
    ========================== -->
    <div class="col-lg-6">
      <div class="card h-100">
        <div class="card-body">
          <div class="d-flex align-items-start justify-content-between gap-2">
            <div>
              <h5 class="card-title mb-1">Evolución y prescripciones</h5>
              <div class="text-muted small">Registro clínico por paciente (encounter).</div>
            </div>
            <span class="badge text-bg-success">Activo</span>
          </div>

          <div class="d-flex flex-wrap gap-2 mt-3">
            <?php if ($canViewClinical): ?>
              <a class="btn btn-outline-primary btn-sm"
                 href="<?= e($BASE) ?>/clinical/encounter.php?patient_id=<?= (int)$patient_id ?>">
                Ver / Historial
              </a>

              <a class="btn btn-outline-dark btn-sm"
                 href="<?= e($BASE) ?>/print/patient_sheet.php?id=<?= (int)$patient_id ?>">
                Imprimir hoja Evo/Prx
              </a>
            <?php endif; ?>

            <?php if ($canEditClinical): ?>
              <a class="btn btn-success btn-sm"
                 href="<?= e($BASE) ?>/clinical/encounter.php?patient_id=<?= (int)$patient_id ?>">
                + Nueva evolución + prescripción
              </a>
            <?php else: ?>
              <span class="text-muted small align-self-center">
                Solo el doctor asignado puede registrar nuevos encounters.
              </span>
            <?php endif; ?>
          </div>
        </div>
      </div>
    </div>

    <!-- =========================
         PROTOCOLO QUIRÚRGICO (NUEVO)
    ========================== -->
    <div class="col-lg-6">
      <div class="card h-100 border-2">
        <div class="card-body">
          <div class="d-flex align-items-start justify-content-between gap-2">
            <div>
              <h5 class="card-title mb-1">Protocolo quirúrgico</h5>
              <div class="text-muted small">
                Ficha MSP/HCU-form 017: incluye diagrama del procedimiento (imagen), rúbrica y sello.
              </div>
            </div>
            <?php if ($protocolId > 0): ?>
              <span class="badge text-bg-primary">Registrado</span>
            <?php else: ?>
              <span class="badge text-bg-secondary">Pendiente</span>
            <?php endif; ?>
          </div>

          <div class="mt-2 text-muted small">
            <?php if ($protocolId > 0): ?>
              Último protocolo: <b>#<?= (int)$protocolId ?></b>
              <?php if (!empty($protocol['updated_at'])): ?>
                &nbsp;|&nbsp; Actualizado: <?= e((string)$protocol['updated_at']) ?>
              <?php else: ?>
                &nbsp;|&nbsp; Creado: <?= e((string)$protocol['created_at']) ?>
              <?php endif; ?>
            <?php else: ?>
              Aún no se ha registrado un protocolo para este paciente.
            <?php endif; ?>
          </div>

          <div class="d-flex flex-wrap gap-2 mt-3">
            <?php if ($canViewProtocol): ?>
              <a class="btn btn-outline-primary btn-sm"
                 href="<?= e($BASE) ?>/protocols/view.php?patient_id=<?= (int)$patient_id ?>">
                Ver protocolo
              </a>

              <?php if ($protocolId > 0): ?>
                <a class="btn btn-outline-dark btn-sm"
                   href="<?= e($BASE) ?>/print/protocol_sheet.php?patient_id=<?= (int)$patient_id ?>">
                  Imprimir protocolo
                </a>
              <?php else: ?>
                <button class="btn btn-outline-dark btn-sm" disabled>Imprimir protocolo</button>
              <?php endif; ?>
            <?php endif; ?>

            <?php if ($canEditProtocol): ?>
              <a class="btn btn-success btn-sm"
                 href="<?= e($BASE) ?>/protocols/form.php?patient_id=<?= (int)$patient_id ?>">
                <?= $protocolId > 0 ? 'Editar / Nuevo protocolo' : '+ Llenar protocolo' ?>
              </a>
            <?php else: ?>
              <span class="text-muted small align-self-center">
                Solo el doctor asignado puede llenar o editar el protocolo.
              </span>
            <?php endif; ?>
          </div>

        </div>
      </div>
    </div>

  </div>

  <div class="mt-4 text-muted small">
    Acceso actual:
    <b><?= e($rol) ?></b>
    <?php if ($isAdmin): ?>
      — Admin (control total)
    <?php elseif ($rol === 'especialista'): ?>
      — Especialista asignado
    <?php else: ?>
      — Residente (solo lectura en ficha, escritura restringida)
    <?php endif; ?>
  </div>

</div>

<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>
