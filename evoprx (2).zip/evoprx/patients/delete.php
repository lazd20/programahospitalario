<?php
require_once __DIR__ . '/../auth.php';
require_login();
require_role(['admin']);
require_once __DIR__ . '/../helpers.php';

$BASE = $GLOBALS['BASE_URL'] ?? '';
$err = null;

$id = (int)($_GET['id'] ?? 0);
if ($id <= 0) {
  flash_set('error', 'ID inválido.');
  redirect($BASE . '/patients/list.php');
}

// Cargar paciente
$st = $pdo->prepare("SELECT id, hc, cedula, nombres, apellidos FROM patients WHERE id=? LIMIT 1");
$st->execute([$id]);
$p = $st->fetch();

if (!$p) {
  flash_set('error', 'Paciente no encontrado.');
  redirect($BASE . '/patients/list.php');
}

// Verificar si tiene registros clínicos
$stEv = $pdo->prepare("SELECT COUNT(*) FROM evolutions WHERE patient_id=?");
$stEv->execute([$id]);
$cntEv = (int)$stEv->fetchColumn();

$stPr = $pdo->prepare("SELECT COUNT(*) FROM prescriptions WHERE patient_id=?");
$stPr->execute([$id]);
$cntPr = (int)$stPr->fetchColumn();

$hasClinical = ($cntEv > 0 || $cntPr > 0);

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
  $confirm = trim((string)($_POST['confirm'] ?? ''));

  if ($confirm !== 'ELIMINAR') {
    $err = 'Escribe ELIMINAR para confirmar.';
  } elseif ($hasClinical) {
    $err = 'No se puede eliminar: el paciente ya tiene evoluciones/prescripciones.';
  } else {
    try {
      // Limpiar asignaciones
      $pdo->prepare("DELETE FROM resident_patients WHERE patient_id=?")->execute([$id]);
      $pdo->prepare("DELETE FROM patient_doctors WHERE patient_id=?")->execute([$id]);

      // Eliminar paciente
      $del = $pdo->prepare("DELETE FROM patients WHERE id=?");
      $del->execute([$id]);

      flash_set('success', 'Paciente eliminado correctamente.');
      redirect($BASE . '/patients/list.php');
    } catch (Throwable $e) {
      $err = 'No se pudo eliminar. Revisa restricciones en la base de datos.';
    }
  }
}

$fullName = trim(($p['apellidos'] ?? '') . ' ' . ($p['nombres'] ?? ''));
?>
<!doctype html>
<html lang="es">
<head>
  <meta charset="utf-8" />
  <meta name="viewport" content="width=device-width, initial-scale=1" />
  <title>Eliminar paciente | Evo/Prx</title>
  <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
</head>
<body>
<?php include __DIR__ . '/../partials/navbar.php'; ?>

<div class="container py-4" style="max-width: 860px;">
  <div class="d-flex justify-content-between align-items-center mb-3">
    <h4 class="mb-0">Eliminar paciente</h4>
    <a class="btn btn-outline-secondary" href="<?= e($BASE) ?>/patients/list.php">Volver</a>
  </div>

  <?php include __DIR__ . '/../partials/flash.php'; ?>

  <?php if ($err): ?>
    <div class="alert alert-danger"><?= e($err) ?></div>
  <?php endif; ?>

  <div class="card shadow-sm">
    <div class="card-body">
      <div class="mb-2">Estás a punto de eliminar a:</div>

      <div class="p-3 border rounded bg-light">
        <div class="fw-semibold"><?= e($fullName) ?></div>
        <div class="text-muted small">
          ID #<?= (int)$p['id'] ?>
          <?php if (!empty($p['hc'])): ?> · HC: <?= e($p['hc']) ?><?php endif; ?>
          <?php if (!empty($p['cedula'])): ?> · Cédula: <?= e($p['cedula']) ?><?php endif; ?>
        </div>
      </div>

      <div class="mt-3 text-muted small">
        Evoluciones: <b><?= (int)$cntEv ?></b> · Prescripciones: <b><?= (int)$cntPr ?></b>
      </div>

      <?php if ($hasClinical): ?>
        <div class="alert alert-warning mt-3 mb-0">
          No se puede eliminar porque ya tiene registros clínicos.
          (Recomendado: mantener el paciente por trazabilidad.)
        </div>
      <?php else: ?>
        <hr class="my-4">

        <form method="post">
          <div class="fw-semibold text-danger mb-1">Confirmación</div>
          <p class="text-muted small mb-2">
            Escribe <b>ELIMINAR</b> para confirmar.
          </p>
          <input class="form-control" name="confirm" placeholder="ELIMINAR" required>

          <div class="mt-3 d-flex gap-2">
            <button class="btn btn-danger">Eliminar definitivamente</button>
            <a class="btn btn-outline-secondary" href="<?= e($BASE) ?>/patients/list.php">Cancelar</a>
          </div>
        </form>
      <?php endif; ?>
    </div>
  </div>
</div>

<?php include __DIR__ . '/../partials/footer.php'; ?>
</body>
</html>