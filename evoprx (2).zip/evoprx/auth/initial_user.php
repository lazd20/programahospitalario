<?php
require_once __DIR__ . '/../helpers.php';
require_once __DIR__ . '/../config.php';

// Si ya existe al menos 1 usuario, bloqueamos este instalador
$exists = (int)$pdo->query("SELECT COUNT(*) FROM users")->fetchColumn();
if ($exists > 0) {
  flash_set('warning', 'Ya existe al menos un usuario. initial_user.php se deshabilita.');
  redirect(base_url('/auth/login.php'));
}

$err = null;

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
  $username = trim((string)($_POST['username'] ?? ''));
  $nombre   = trim((string)($_POST['nombre'] ?? ''));
  $apellido = trim((string)($_POST['apellido'] ?? ''));
  $pass1    = (string)($_POST['password'] ?? '');
  $pass2    = (string)($_POST['password2'] ?? '');

  if ($username === '' || $pass1 === '' || $pass2 === '') {
    $err = 'Completa usuario y contraseña.';
  } elseif ($pass1 !== $pass2) {
    $err = 'Las contraseñas no coinciden.';
  } elseif (strlen($pass1) < 6) {
    $err = 'Contraseña muy corta (mínimo 6 caracteres).';
  } else {
    $hash = password_hash($pass1, PASSWORD_DEFAULT);

    try {
      $st = $pdo->prepare("
        INSERT INTO users (username, password, rol, nombre, apellido, created_at)
        VALUES (?, ?, 'admin', ?, ?, NOW())
      ");
      $st->execute([$username, $hash, $nombre, $apellido]);

      flash_set('success', 'Admin inicial creado. Ya puedes iniciar sesión.');
      redirect(base_url('/auth/login.php'));
    } catch (Throwable $e) {
      $err = 'No se pudo crear el usuario. Revisa si el username ya existe.';
    }
  }
}
?>
<!doctype html>
<html lang="es">
<head>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <title>Crear admin inicial</title>
  <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
</head>
<body class="bg-light">
<div class="container py-5" style="max-width:520px;">
  <div class="card shadow-sm">
    <div class="card-body">
      <h5 class="mb-3">Crear Admin Inicial</h5>

      <?php if ($err): ?>
        <div class="alert alert-danger"><?= e($err) ?></div>
      <?php endif; ?>

      <form method="post">
        <div class="mb-2">
          <label class="form-label">Usuario</label>
          <input class="form-control" name="username" required>
        </div>

        <div class="row g-2">
          <div class="col-6">
            <label class="form-label">Nombre</label>
            <input class="form-control" name="nombre">
          </div>
          <div class="col-6">
            <label class="form-label">Apellido</label>
            <input class="form-control" name="apellido">
          </div>
        </div>

        <div class="mt-2">
          <label class="form-label">Contraseña</label>
          <input type="password" class="form-control" name="password" required>
        </div>

        <div class="mt-2">
          <label class="form-label">Repetir contraseña</label>
          <input type="password" class="form-control" name="password2" required>
        </div>

        <button class="btn btn-success w-100 mt-3">Crear admin</button>
      </form>

      <div class="text-muted small mt-3">
        * Después de crear el admin, elimina o renombra <b>initial_user.php</b> por seguridad.
      </div>
    </div>
  </div>
</div>
</body>
</html>