<?php
// config.php
// Conexión PDO MySQL (Bootstrap + PHP)
// IMPORTANTE: en producción, protege este archivo (permisos correctos / fuera de public_html si puedes).

define('DB_HOST', 'localhost');
define('DB_NAME', 'sitiosnuevos_PROTOCOLSO');
define('DB_USER', 'sitiosnuevos_454RFGERF');

// ⚠️ Por seguridad, pega tu contraseña real aquí SOLO en tu servidor:
define('DB_PASS', 'K,C~[C3PZh($WH!m');

define('DB_CHARSET', 'utf8mb4');

// Base URL del proyecto (ajústalo a tu carpeta):
// Ejemplos:
// define('BASE_URL', '');               // si está en la raíz del dominio
// define('BASE_URL', '/pqx');           // si está en https://tudominio.com/pqx
define('BASE_URL', '/evoprx');

$GLOBALS['BASE_URL'] = BASE_URL;

try {
  $dsn = "mysql:host=" . DB_HOST . ";dbname=" . DB_NAME . ";charset=" . DB_CHARSET;

  $pdo = new PDO($dsn, DB_USER, DB_PASS, [
    PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION,
    PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC,
    PDO::ATTR_EMULATE_PREPARES => false,
  ]);
} catch (Throwable $e) {
  http_response_code(500);
  die("Error de conexión a la base de datos. Revisa config.php");
}
