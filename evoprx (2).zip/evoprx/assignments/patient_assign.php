<?php
require_once __DIR__ . '/../auth.php';
require_login();
require_role(['admin']);
require_once __DIR__ . '/../helpers.php';

$BASE = $GLOBALS['BASE_URL'] ?? '';

$patient_id = (int)($_GET['patient_id'] ?? 0);
$err = null;

// ====== Lista pacientes para selector ======
$patients = $pdo->query("SELECT id, hc, apellidos, nombres FROM patients ORDER BY apellidos, nombres")->fetchAll();

// Si no viene patient_id, usar el primero
if ($patient_id <= 0 && $patients) {
  $patient_id = (int)$patients[0]['id'];
}

if ($patient_id <= 0) {
  flash_set('error', 'No hay pacientes creados.');
  redirect($BASE . '/patients/list.php');
}

// Cargar paciente actual
$stP = $pdo->prepare("SELECT id, hc, cedula, apellidos, nombres FROM patients WHERE id=? LIMIT 1");
$stP->execute([$patient_id]);
$p = $stP->fetch();
if (!$p) {
  flash_set('error', 'Paciente no encontrado.');
  redirect($BASE . '/patients/list.php');
}

// ====== Lista de especialistas (tratantes) ======
$doctors = $pdo->query("
  SELECT id, apellido, nombre
  FROM users
  WHERE rol IN ('especialista','admin')
  ORDER BY apellido, nombre
")->fetchAll();

// ====== Lista de residentes ======
$residents = $pdo->query("
  SELECT id, apellido, nombre
  FROM users
  WHERE rol = 'residente'
  ORDER BY apellido, nombre
")->fetchAll();

// ====== Tratante actual ======
$stD = $pdo->prepare("SELECT doctor_user_id FROM patient_doctors WHERE patient_id=? LIMIT 1");
$stD->execute([$patient_id]);
$currentDoctorId = (int)($stD->fetchColumn() ?? 0);

// ====== Residentes actuales ======
$stR = $pdo->prepare("SELECT resident_user_id FROM resident_patients WHERE patient_id=?");
$stR->execute([$patient_id]);
$currentResidents = array_map('intval', array_column($stR->fetchAll(), 'resident_user_id'));

// ====== Guardar ======
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
  $patient_id_post = (int)($_POST['patient_id'] ?? 0);
  if ($patient_id_post !== $patient_id) {
    // Si cambió el selector por POST, redirigir con el nuevo
    redirect($BASE . '/assignments/patient_assign.php?patient_id=' . (int)$patient_id_post);
  }

  $doctor_user_id = (int)($_POST['doctor_user_id'] ?? 0);
  $resident_ids = $_POST['resident_ids'] ?? [];
  if (!is_array($resident_ids)) $resident_ids = [];
  $resident_ids = array_values(array_unique(array_map('intval', $resident_ids)));
  $resident_ids = array_filter($resident_ids, fn($x) => $x > 0);

  if ($doctor_user_id <= 0) {
    $err = 'Debes seleccionar un médico tratante.';
  } else {
    try {
      $pdo->beginTransaction();

      // 1) Setear tratante (1 por paciente)
      // Borra y vuelve a insertar (simple y seguro)
      $pdo->prepare("DELETE FROM patient_doctors WHERE patient_id=?")->execute([$patient_id]);
      $pdo->prepare("INSERT INTO patient_doctors (patient_id, doctor_user_id) VALUES (?, ?)")
          ->execute([$patient_id, $doctor_user_id]);

      // 2) Setear residentes (N por paciente)
      $pdo->prepare("DELETE FROM resident_patients WHERE patient_id=?")->execute([$patient_id]);

      if ($resident_ids) {
        $ins = $pdo->prepare("INSERT INTO resident_patients (patient_id, resident_user_id) VALUES (?, ?)");
        foreach ($resident_ids as $rid) {
          $ins->execute([$patient_id, $rid]);
        }
      }

      $pdo->commit();

      flash_set('success', 'Asignaciones guardadas correctamente.');
      redirect($BASE . '/assignments/patient_assign.php?patient_id=' . (int)$patient_id);
    } catch (Throwable $e) {
      $pdo->rollBack();
      $err = 'No se pudo guardar. Revisa la base de datos y permisos.';
    }
  }
}

$patientName = trim(($p['apellidos'] ?? '') . ' ' . ($p['nombres'] ?? ''));
?>
<!doctype html>
<html lang="es">
<head>
  <meta charset="utf-8" />
  <meta name="viewport" content="width=device-width, initial-scale=1" />
  <title>Asignaciones | Evo/Prx</title>
  <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
</head>
<body>
<?php include __DIR__ . '/../partials/navbar.php'; ?>

<div class="container py-4" style="max-width: 1050px;">
  <div class="d-flex flex-column flex-md-row justify-content-between align-items-md-center gap-2 mb-3">
    <div>
      <h4 class="mb-0">Asignar tratante y residentes</h4>
      <div class="text-muted small">Paciente: <b><?= e($patientName) ?></b></div>
    </div>
    <div class="d-flex gap-2">
      <a class="btn btn-outline-secondary" href="<?= e($BASE) ?>/patients/view.php?id=<?= (int)$patient_id ?>">Ficha</a>
      <a class="btn btn-outline-secondary" href="<?= e($BASE) ?>/patients/list.php">Pacientes</a>
    </div>
  </div>

  <?php include __DIR__ . '/../partials/flash.php'; ?>
  <?php if ($err): ?>
    <div class="alert alert-danger"><?= e($err) ?></div>
  <?php endif; ?>

  <form method="post" class="card shadow-sm">
    <div class="card-body">
      <div class="row g-3">
        <div class="col-lg-6">
          <label class="form-label">Paciente</label>
          <select class="form-select" name="patient_id" onchange="this.form.submit()">
            <?php foreach ($patients as $pp): ?>
              <?php
                $pid = (int)$pp['id'];
                $label = trim(($pp['apellidos'] ?? '').' '.($pp['nombres'] ?? ''));
                $hc = (string)($pp['hc'] ?? '');
                if ($hc !== '') $label .= " (HC: {$hc})";
              ?>
              <option value="<?= $pid ?>" <?= $pid===(int)$patient_id?'selected':'' ?>>
                <?= e($label) ?>
              </option>
            <?php endforeach; ?>
          </select>
          <div class="form-text">Cambiar paciente recarga esta misma pantalla.</div>
        </div>

        <div class="col-lg-6">
          <label class="form-label">Médico tratante (especialista)</label>
          <select class="form-select" name="doctor_user_id" required>
            <option value="">— Seleccionar —</option>
            <?php foreach ($doctors as $d): ?>
              <?php $did = (int)$d['id']; ?>
              <option value="<?= $did ?>" <?= $did===$currentDoctorId?'selected':'' ?>>
                <?= e(trim($d['apellido'].' '.$d['nombre'])) ?>
              </option>
            <?php endforeach; ?>
          </select>
          <div class="form-text">Debe existir 1 tratante por paciente.</div>
        </div>

        <div class="col-12">
          <hr>
          <div class="d-flex justify-content-between align-items-center">
            <div class="fw-semibold">Residentes asignados</div>
            <div class="text-muted small">Selecciona uno o varios</div>
          </div>
        </div>

        <div class="col-12">
          <?php if (!$residents): ?>
            <div class="alert alert-warning mb-0">No hay residentes creados.</div>
          <?php else: ?>
            <div class="row g-2">
              <?php foreach ($residents as $r): ?>
                <?php
                  $rid = (int)$r['id'];
                  $checked = in_array($rid, $currentResidents, true) ? 'checked' : '';
                ?>
                <div class="col-md-4 col-lg-3">
                  <div class="form-check border rounded p-2 bg-light">
                    <input class="form-check-input" type="checkbox" name="resident_ids[]"
                           value="<?= $rid ?>" id="res<?= $rid ?>" <?= $checked ?>>
                    <label class="form-check-label" for="res<?= $rid ?>">
                      <?= e(trim($r['apellido'].' '.$r['nombre'])) ?>
                    </label>
                  </div>
                </div>
              <?php endforeach; ?>
            </div>
          <?php endif; ?>
        </div>

        <div class="col-12">
          <div class="alert alert-info mb-0">
            Los residentes y el tratante verán al paciente en su lista según estas asignaciones.
          </div>
        </div>
      </div>
    </div>

    <div class="card-footer d-flex gap-2">
      <button class="btn btn-primary">Guardar asignaciones</button>
      <a class="btn btn-outline-secondary" href="<?= e($BASE) ?>/patients/view.php?id=<?= (int)$patient_id ?>">Volver a ficha</a>
    </div>
  </form>
</div>

<?php include __DIR__ . '/../partials/footer.php'; ?>
</body>
</html>